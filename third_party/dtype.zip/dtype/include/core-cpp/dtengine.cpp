/*
 * engine.h - D-Type Engine
 * Copyright (C) 1996-2017 D-Type Solutions
 * Web Site: http://www.d-type.com
 * E-mail: info@d-type.com
 */

// Main D-Type header file
#include "../core/dtype.h"


#ifndef DEF_ENGINE_LEVEL
#error "dtengine.cpp: DEF_ENGINE_LEVEL not defined! It must be 0, 1, 2, 3 or 4."
#elif (DEF_ENGINE_LEVEL == 0)
#else

// Header for this file
#include "dtengine.h"

#include "../extras/dtextras.cpp"
#include "../extras/dtshapes.cpp"


bool CDTEngineV7::Init(const DT_STREAM_DESC* sd_init, const DT_STREAM_DESC* sd_fontmap, DT_INIT_INFO* init_info)
{
	Engine = NULL;

	StoredStyle.effects_len = 0;
	for (DT_SLONG i = 0; i < 64; i++) StoredStyle.effects_arr[i] = 0;
	StoredStyle.rgbt[0] = StoredStyle.rgbt[1] = StoredStyle.rgbt[2] = StoredStyle.rgbt[3] = 0;
	StoredStyle.palette = NULL;

	StoredType.font_index = 0;
	StoredType.reserved = 0;
	StoredType.descriptor = 0;
	StoredType.transform.params.size_h = StoredType.transform.params.size_v = 100;
	StoredType.transform.params.skew_h = StoredType.transform.params.skew_v = 0;
	StoredType.transform.params.rotation = 0;
	StoredType.linedecor.thickness = 0;
	StoredType.linedecor.segment = 0;
	StoredType.linedecor.shift = 0;
	StoredType.linedecor.dash_size = 0;
	StoredType.linedecor.flags = 0;
	StoredType.linedecor.scale_id = DV_SCALE_100;

	DT_STREAM_MEMORY(fontmap_sd_cached, NULL, 0);
	DefaultFontmap = fontmap_sd_cached;

	if (sd_init == NULL) return false;

#if (DEF_ENGINE_LEVEL == 1)

	if (dtEngineIniViaStream(&Engine, sd_init, init_info) != 1) return false;
	(void)sd_fontmap;

#elif (DEF_ENGINE_LEVEL == 2)

	if (dtEngineIniViaStream(&Engine, sd_init, init_info) != 1) return false;
	if (lxCacheIni(&LayoutCache, Engine, 0) != 1) { dtEngineExt(Engine); return false; }
	(void)sd_fontmap;

#elif (DEF_ENGINE_LEVEL == 3)

	if (pdEngineIniViaStream(&Engine, sd_init, init_info) != 1) return false;
	(void)sd_fontmap;

#else

	if (txEngineIniViaStream(&Engine, sd_init, init_info) != 1) return false;
	if (sd_fontmap == NULL) return true;
	if (txEngineMakeCachedFontmap(Engine, sd_fontmap, &DefaultFontmap, 0) != 1) { Exit(); return false; }

#endif

	return true;
}


void CDTEngineV7::Exit()
{
#if (DEF_ENGINE_LEVEL == 1)

	if (Engine != NULL) dtEngineExt(Engine);

#elif (DEF_ENGINE_LEVEL == 2)

	if (LayoutCache != NULL) lxCacheExt(LayoutCache); LayoutCache = NULL;
	if (Engine != NULL) dtEngineExt(Engine);

#elif (DEF_ENGINE_LEVEL == 3)

	if (Engine != NULL) pdEngineExt(Engine);

#else

	if (Engine != NULL) txEngineExt(Engine);
	// release memory that txEngineMakeCachedFontmap allocated for the cached font map
	if (DefaultFontmap.stream_id == 2 && DefaultFontmap.stream_locator.mem_w.addr != NULL) txFree(DefaultFontmap.stream_locator.mem_w.addr);
	DefaultFontmap.stream_locator.mem_w.addr = NULL;

	DT_STREAM_MEMORY(fontmap_sd_cached, NULL, 0);
	DefaultFontmap = fontmap_sd_cached;

#endif

	Engine = NULL;
}


#if (DEF_ENGINE_LEVEL == 1 || DEF_ENGINE_LEVEL == 2)
#else

//#define DEF_PDX_ZLIB
//#define DEF_PDX_LIBPNG
//#define DEF_PDX_LIBJPG

#include "../extras/pdextras.cpp"

bool CDTDocV7::Init(CDTEngineV7* engine)
{
	Engine = engine;

	PdDoc = NULL;
	TxDoc = NULL;

	if (pdDocIni(&PdDoc, (Engine == NULL ? NULL : Engine->GetPdEngine())) != 1) return false;
	if (PdDoc == NULL) return false;

	pdDocSetNumericValue(PdDoc, PD_NVAL_TEXT_BLANKS_SIZE, 512);

#if (DEF_ENGINE_LEVEL == 3)
#else
	//txTextIniViaPowerDocAndBuffer(&TxDoc, PdDoc, 0, NULL, 0, 0 /*TX_IMPORT_POWERDOC_REFORMAT*/, NULL, NULL, Engine->GetDefaultFontmap(), 0);
	if (txTextIniViaPowerDoc(&TxDoc, PdDoc) < 0) return false; /* same as txTextIniViaPowerDocAndBuffer(&TxDoc, PdDoc, 0, NULL, 0, 0, NULL, NULL, NULL, 0); */
	if (TxDoc == NULL) return false;

	DT_PD_DOC_PARAMS pd_params = {4 /*runtime->ImageOriginsNormalSize*/, 6 /*runtime->ImageOriginsSelectedSize*/, 10, 10, 2, 0, 1, 2 + 8};
	DT_TX_DOC_PARAMS tx_params = {15, 1 + 16 + 256 + 512, &pd_params};
	txTextSetParams(TxDoc, &tx_params, 0);

	txTextCommand(TxDoc, TX_CMD_RESET, NULL, 0);
#endif

	//BlendBlanks[0] = TX_BLEND_HIGHLIGHT_1; BlendBlanks[1] = 235; BlendBlanks[2] = 235; BlendBlanks[3] = 235; BlendBlanks[4] = 0;
	//txTextSetHighlighterPlus(TxDoc, extra->BlendCursor, extra->BlendSelect, extra->BlendBlanks, 0);

	return true;
}


void CDTDocV7::Exit()
{
#if (DEF_ENGINE_LEVEL == 3)
#else
	if (TxDoc != NULL) txTextExt(TxDoc);
	TxDoc = NULL;
#endif

	if (PdDoc != NULL) pdDocExt(PdDoc);
	PdDoc = NULL;
}


DT_SLONG CDTDocV7::Draw(DT_SLONG page, DT_SLONG x_off, DT_SLONG y_off, DT_ID_SWORD format, DT_ID_SWORD subformat, DT_MDC* memory_surface, DT_PD_DOCDRAW_PARAMS* params, DT_ID_SWORD flags)
{
#if (DEF_ENGINE_LEVEL == 3)
	(void)flags;
	return pdDocDraw(PdDoc, page, x_off, y_off, format, subformat, memory_surface, params);
#else
	return txTextDraw(TxDoc, page, x_off, y_off, format, subformat, memory_surface, params, flags);
#endif
}


void CDTDocV7::Deselect()
{
	pdxImgAllDeselect(PdDoc);
}


void CDTDocV7::Cleanup()
{
	DT_SLONG i = 0, max_pass = 50;

	pdxImgAllDeleteOnPage(PdDoc, DV_PAGE_TEMP);
	pdxImgAllDeleteOnPage(PdDoc, DV_PAGE_NEST);

	pdxDocReconnectFonts(PdDoc);

	while (i < max_pass)
	{
		DT_SLONG n1 = ObjGetLast(); pdDocDiscardOrphansPlus(PdDoc, 0, "!");
		DT_SLONG n2 = ObjGetLast(); if (n1 == n2) break;
		i++;
	}
}


DT_SLONG CDTDocV7::Save(DT_SWORD flag, DT_STREAM_DESC* sd)
{
	Cleanup();

	DT_SLONG res = pdxDocSaveToStream(PdDoc, flag, sd);

		 if (res == -3) LogError("Compression error!\n");
	else if (res == -2) LogError("Not enough memory to save compressed document!\n");
	else if (res !=  1) LogError("Error saving document!\n");

	return res;
}


DT_SLONG CDTDocV7::Append(DT_SLONG page, DT_SLONG x, DT_SLONG y, const DT_STREAM_DESC* sd, bool make_group /*= false*/, bool deselect /*= false*/, bool select /*= false*/)
{
	DT_PDDOC power_doc_temp = NULL;
	if (pdDocIni(&power_doc_temp, Engine->GetPdEngine()) == 0) return -1;

	DT_SLONG img_last = pdImgGetLast(PdDoc);
	DT_SLONG ret = 0;

	ret = pdxDocAppendFromStream(power_doc_temp, 2, 0, 0, 0, sd);

	     if (ret == -3) { LogError("Decompression error!\n"); goto end; }
	else if (ret == -2) { LogError("Not enough memory to open compressed document!\n"); goto end; }
	else if (ret !=  1) { LogError("Error opening PowerDoc document or the file does not exist!\n"); goto end; }

	if (make_group)
	{
		pdxImgSelSelectByPageRange(power_doc_temp, 0, 0);
		pdxImgSelGroup(power_doc_temp, 0, 0, 0, 1);
	}

	if (deselect) pdxImgAllDeselect(PdDoc);

	pdDocAppend(PdDoc, page, x, y, power_doc_temp);

	if (select) pdxImgSelSelectByImgRange(PdDoc, img_last + 1, ImgGetLast());

end:

	pdDocExt(power_doc_temp);
	return ret;
}


#endif

#endif
