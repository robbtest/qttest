/*
 *
 * Copyright (C) D-Type Solutions - All Rights Reserved
 * Web Site: http://www.d-type.com
 * E-mail: info@d-type.com
 *
 * This file is part of D-Type Engine and may only be used, modified
 * and distributed under the terms of the applicable license agreement
 * For conditions of distribution and use, see license.txt
 *
 * ANY VIOLATIONS OF THE ABOVE LICENSE AGREEMENT WILL BE PROSECUTED TO
 * THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW. NO VENDOR, DISTRIBUTOR,
 * DEALER, RETAILER, SALES PERSON OR OTHER PERSON IS AUTHORIZED TO MODIFY
 * THIS AGREEMENT OR TO MAKE ANY WARRANTY, REPRESENTATION OR PROMISE WHICH
 * IS DIFFERENT THAN, OR IN ADDITION TO, THIS AGREEMENT.
 *
 */


#include <memory.h>

#include "DTWindowPlatform.h"


CDTDisplayPlatform::CDTDisplayPlatform(DT_ULONG /*flags*/)
{
	WindowsArr = NULL;
	WindowsCount = 0;
	WindowsLimit = 0;
}


CDTDisplayPlatform::~CDTDisplayPlatform()
{
	if (WindowsArr != NULL) dtMemFree(WindowsArr);
	WindowsArr = NULL;
	WindowsCount = 0;
	WindowsLimit = 0;
}


bool CDTDisplayPlatform::WindowRegsiter(CDTWindowBase* window)
{
	if (window == NULL) return false;

	DT_SLONG i;

	for (i = 0; i < WindowsCount; i++)
	{
		if (WindowsArr[i] == window) return true; /* already registered */
	}

	if (WindowsCount >= DV_WINDOW_WINDOW_MAX) return false; /* we have too many registered windows */

	if (WindowsCount >= WindowsLimit) /* reallocate */
	{
		DT_SLONG new_limit = WindowsLimit + DV_WINDOW_WINDOW_INC;
		CDTWindowBase** new_windows = (CDTWindowBase**)dtMemRealloc(WindowsArr, new_limit * sizeof(CDTWindowBase*));
		if (new_windows == NULL) return false;
		WindowsArr = new_windows;
		WindowsLimit = new_limit;
	}

	/* new registration */
	WindowsArr[WindowsCount] = window;
	WindowsCount++;
	return true;
}


void CDTDisplayPlatform::WindowUnregsiter(const CDTWindowBase* window)
{
	if (window == NULL || WindowsCount <= 0) return;

	DT_SLONG i, j = 0, c = WindowsCount;

	for (i = 0; i < c; i++)
	{
		if (j != i) WindowsArr[j] = WindowsArr[i];
		if (WindowsArr[i] == window) WindowsCount--; /* window to be unregsitered */ else j++; /* window to be kept */
	}
}


void CDTDisplayPlatform::EventLoop()
{
	if (WindowsCount <= 0) return;

	WindowsArr[0]->event_loop();
}


void CDTDisplayPlatform::OnPeriodic()
{
	if (WindowsCount <= 0) return;

	DT_SLONG i;

	for (i = 0; i < WindowsCount; i++)
	{
		WindowsArr[i]->onPeriodic();
	}
}

