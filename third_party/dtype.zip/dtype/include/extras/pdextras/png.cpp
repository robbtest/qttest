/*
 * Basic PNG support for D-Type Power Engine
 * Copyright (C) 1996-2017 D-Type Solutions
 * Web Site: http://www.d-type.com
 * E-mail: info@d-type.com
 */


#include "png/png.h"


void pdxPNGFlush(png_structp /*png_ptr*/) {}


void pdxPNGWrite(png_structp png_ptr, png_bytep data, png_size_t length)
{
	DT_PDX_USER_STREAM* user_stream = (DT_PDX_USER_STREAM*)png_get_io_ptr(png_ptr);
	user_stream->UserFunc(user_stream->UserStruct, data, length);
}


DT_SLONG pdxPNGMake(DT_UBYTE* bmp_ptr, DT_SWORD format, DT_SWORD /*subformat*/, DT_SLONG wcl, DT_SLONG hcl, DT_UBYTE orientation, DT_SLONG padding, const DT_PDX_GRAPHICS_ATTRIBS* gattribs, DT_FILE_PTR file_ptr, DT_PDX_USER_STREAM* user_stream)
{
	png_structp png_ptr = NULL;
	png_infop info_ptr = NULL;
	png_bytep* row_ptr = NULL;
	png_color palette[256];
	png_color_16 trans_value;
	png_byte trans[256];
	DT_PDX_GRAPHICS_ATTRIBS g = {255, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0};
	const DT_PDX_GRAPHICS_ATTRIBS* gp = &g;

	DT_SLONG i = 0, ret = 0, y = 0, dy = 1, bpr;

	if (gattribs != NULL) gp = gattribs;

	trans_value.red = gp->R1;
	trans_value.green = gp->G1;
	trans_value.blue = gp->B1;
	trans_value.gray = 255;
	trans_value.index = 0;

	if ((png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL)) == NULL) return 0;

	if ((info_ptr = png_create_info_struct(png_ptr)) == NULL)
	{
		png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
		return 0;
	}

	if (setjmp(png_jmpbuf(png_ptr)))
	{
		png_destroy_write_struct(&png_ptr, &info_ptr);
		return 0;
	}

	bpr = wcl;

	if (format == 24)
	{
		bpr *= 3;
		png_set_IHDR(png_ptr, info_ptr, wcl, hcl, 8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_ADAM7, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
		if (gp->TransparencyFlag != 0) png_set_tRNS(png_ptr, info_ptr, trans, 0, &trans_value);

	}
	else if (format == 8)
	{
		if (gp->PaletteFlag == 1)
		{
			for (i = 0; i <= 255; i++)
			{
				palette[i].red =   (DT_UBYTE)((gp->R1 * i + gp->R2 * (255 - i)) / 255);
				palette[i].green = (DT_UBYTE)((gp->G1 * i + gp->G2 * (255 - i)) / 255);
				palette[i].blue =  (DT_UBYTE)((gp->B1 * i + gp->B2 * (255 - i)) / 255);
				if (gp->TransparencyFlag == 2) trans[i] = (DT_UBYTE)(255 - i); else trans[i] = 255;
			}
			trans[255] = 0;

			png_set_IHDR(png_ptr, info_ptr, wcl, hcl, 8, PNG_COLOR_TYPE_PALETTE, PNG_INTERLACE_ADAM7, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
			png_set_PLTE(png_ptr, info_ptr, palette, 256);
			if (gp->TransparencyFlag != 0) png_set_tRNS(png_ptr, info_ptr, trans, 256, &trans_value);
		}
		else
		{
			png_set_IHDR(png_ptr, info_ptr, wcl, hcl, 8, PNG_COLOR_TYPE_GRAY, PNG_INTERLACE_ADAM7, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
			if (gp->TransparencyFlag != 0) png_set_tRNS(png_ptr, info_ptr, trans, 0, &trans_value);
		}
	}
	else
	{
		png_destroy_write_struct(&png_ptr, &info_ptr);
		return 0;
	}

	if (file_ptr != NULL) png_init_io(png_ptr, file_ptr); else png_set_write_fn(png_ptr, user_stream, &pdxPNGWrite, &pdxPNGFlush);

	png_write_info(png_ptr, info_ptr);

	if ((row_ptr = (png_bytep*)DF_PDX_MEM_ALLOC(hcl * sizeof(png_bytep))) != NULL)
	{
		if (orientation == 1) { y = hcl - 1; dy = -1; }

		for (i = 0; i < hcl; i++, y += dy, bmp_ptr += bpr + padding)
		{
			row_ptr[y] = (png_bytep)bmp_ptr;

#ifdef IMAGE_ROW_DEBUG
			IMAGE_ROW_DEBUG(format, 0 /*subformat*/, wcl, hcl, bmp_ptr, y);
#endif
		}

		png_set_bgr(png_ptr);
		png_write_image(png_ptr, row_ptr);
		png_write_end(png_ptr, info_ptr);

		DF_PDX_MEM_FREE(row_ptr);
		ret = 1;
	}

	png_destroy_write_struct(&png_ptr, &info_ptr);

	return ret;
}


DT_SLONG pdxPNGLoad(DT_UBYTE** bmp_ptr, DT_SWORD* format, DT_SLONG* wcl, DT_SLONG* hcl, DT_UBYTE orientation, const DT_PDX_GRAPHICS_ATTRIBS* gattribs, DT_FILE_PTR file_ptr)
{
	png_structp png_ptr = NULL;
	png_infop info_ptr = NULL;
	png_bytep* row_ptr = NULL;
	unsigned int sig_read = 0;
	double gamma_screen = 2.2;
	png_color_16 my_background = {0, 255, 255, 255, 255}, *image_background;
	//unsigned int png_transforms = PNG_TRANSFORM_STRIP_16 | PNG_TRANSFORM_STRIP_ALPHA | PNG_TRANSFORM_PACKING;

	DT_SLONG i = 0, ret = 0, y = 0, dy = 1;
	DT_SLONG bpr;
	DT_SLONG bit_depth, bit_depth2, color_type, color_type2;
	DT_UBYTE alpha_flag = 0;
	DT_UBYTE* ptr;

	*format = 0;
	*bmp_ptr = NULL;

	if (gattribs != NULL)
	{
		my_background.red = gattribs->R1;
		my_background.green = gattribs->G1;
		my_background.blue = gattribs->B1;
		alpha_flag = gattribs->AlphaFlag;
	}

	/*
		Create and initialize the png_struct with the desired error handler
		functions. If you want to use the default stderr and longjump method,
		you can supply NULL for the last three parameters. We also supply the
		the compiler header file version, so that we know if the application
		was compiled with a compatible version of the library. REQUIRED
	*/

	if ((png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL)) == NULL) return 0;

	/* Allocate/initialize the memory for image information. REQUIRED. */
	if ((info_ptr = png_create_info_struct(png_ptr)) == NULL)
	{
		png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
		return 0;
	}

	/*
		Set error handling if you are using the setjmp/longjmp method (this is
		the normal method of doing things with libpng). REQUIRED unless you
		set up your own error handlers in the png_create_read_struct() earlier.
	*/

	if (setjmp(png_jmpbuf(png_ptr)))
	{
		/* Free all of the memory associated with the png_ptr and info_ptr */
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		/* If we get here, we had a problem reading the file */
		return 0;
	}

	/* Set up the input control if you are using standard C streams */
	png_init_io(png_ptr, file_ptr);

	/* If we have already read some of the signature */
	png_set_sig_bytes(png_ptr, sig_read);

	/*
		If you have enough memory to read in the entire image at once,
		and you need to specify only transforms that can be controlled
		with one of the PNG_TRANSFORM_* bits (this presently excludes
		dithering, filling, setting background, and doing gamma
		adjustment), then you can read the entire image (including
		pixels) into the info structure with this call:
	*/

	//png_read_png(png_ptr, info_ptr, png_transforms, NULL);
	//row_ptr = png_get_rows(png_ptr, info_ptr);

	png_read_info(png_ptr, info_ptr);

	*wcl = png_get_image_width(png_ptr, info_ptr);
	*hcl = png_get_image_height(png_ptr, info_ptr);
	bit_depth2 = bit_depth = png_get_bit_depth(png_ptr, info_ptr);
	color_type2 = color_type = png_get_color_type(png_ptr, info_ptr);

	if (bit_depth < 8)
	{
		png_set_packing(png_ptr);
		bit_depth2 = 8;
	}
	else if (bit_depth == 16)
	{
		png_set_strip_16(png_ptr);
		bit_depth2 = 8;
	}

	if (color_type == PNG_COLOR_TYPE_PALETTE)
	{
		png_set_palette_to_rgb(png_ptr);
		color_type2 = PNG_COLOR_TYPE_RGB;
	}

	if (color_type2 == PNG_COLOR_TYPE_RGB)
	{
		if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) { png_set_tRNS_to_alpha(png_ptr); color_type2 = PNG_COLOR_TYPE_RGB_ALPHA; }
	}
	else if (color_type2 == PNG_COLOR_TYPE_GRAY)
	{
		if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) { png_set_tRNS_to_alpha(png_ptr); color_type2 = PNG_COLOR_TYPE_GRAY_ALPHA; }

		if (bit_depth < 8)
		{
			/*
				As of libpng version 1.2.9, png_set_expand_gray_1_2_4_to_8() was added. It expands the sample depth without changing tRNS to alpha.
				At the same time, png_set_gray_1_2_4_to_8() was deprecated, and it will be removed from a future version.
			*/

			//png_set_gray_1_2_4_to_8(png_ptr);
			png_set_expand_gray_1_2_4_to_8(png_ptr);
			bit_depth2 = 8;
		}
	}

	/*
		if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png_ptr);
		if (color_type & PNG_COLOR_MASK_ALPHA) png_set_strip_alpha(png_ptr);
	*/

	png_set_invert_alpha(png_ptr);

	if (alpha_flag == 0 || color_type2 == PNG_COLOR_TYPE_GRAY || color_type2 == PNG_COLOR_TYPE_RGB)
	{
		if (png_get_bKGD(png_ptr, info_ptr, &image_background) && gattribs == NULL)
			png_set_background(png_ptr, image_background, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
		else
			png_set_background(png_ptr, &my_background, PNG_BACKGROUND_GAMMA_SCREEN, 0, gamma_screen);

		if (color_type2 == PNG_COLOR_TYPE_GRAY_ALPHA) color_type2 = PNG_COLOR_TYPE_GRAY;
		else if (color_type2 == PNG_COLOR_TYPE_RGB_ALPHA) color_type2 = PNG_COLOR_TYPE_RGB;
	}

	bpr = 0;

	if (bit_depth2 == 8)
	{
		if (color_type2 == PNG_COLOR_TYPE_GRAY)
		{
			*format = 8;
			bpr = *wcl;
		}
		else if (color_type2 == PNG_COLOR_TYPE_GRAY_ALPHA)
		{
			*format = 16;
			bpr = *wcl * 2;
		}
		else if (color_type2 == PNG_COLOR_TYPE_RGB)
		{
			*format = 24;
			bpr = *wcl * 3;
		}
		else if (color_type2 == PNG_COLOR_TYPE_RGB_ALPHA)
		{
			*format = 32;
			bpr = *wcl * 4;
		}
	}

	if (*format != 0)
	{
		*bmp_ptr = ptr = (DT_UBYTE*)DF_PDX_MEM_ALLOC(*hcl * bpr);
		row_ptr = (png_bytep*)DF_PDX_MEM_ALLOC(*hcl * sizeof(png_bytep));

		if (row_ptr != NULL && ptr != NULL)
		{
			if (orientation == 1) { y = *hcl - 1; dy = -1; }

			for (i = 0; i < *hcl; i++, y += dy, ptr += bpr) row_ptr[y] = (png_bytep)ptr;

			png_set_bgr(png_ptr);
			png_read_image(png_ptr, row_ptr);
			png_read_end(png_ptr, NULL);

			ret = 1;
		}

		if (row_ptr != NULL) DF_PDX_MEM_FREE(row_ptr);

		//for (i = 0; i < *hcl; i++, ptr += bpr) memcpy(ptr, row_ptr[i], bpr);
	}

	/* At this point you have read the entire image clean up after the read, and free any memory allocated - REQUIRED */
	png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);

	return ret;
}
