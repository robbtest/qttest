/*
 * Compression/Decompression for D-Type Power Engine
 * Copyright (C) 1996-2017 D-Type Solutions
 * Web Site: http://www.d-type.com
 * E-mail: info@d-type.com
 */


#include "zlib/zlib.h"


#define DV_PDX_ZLIB_MAXBUFFERSIZE 2147483647


inline DT_SLONG pdxZLIBGetCompressBound(DT_SLONG raw_len)
{
	if (raw_len < 1) return 0;
	uLong tmp_ret = compressBound(raw_len);
	if (tmp_ret >= DV_PDX_ZLIB_MAXBUFFERSIZE) return 0;
	DT_SLONG ret = (DT_SLONG)tmp_ret;
	return ret;
}


DT_SWORD pdxZLIBCompressPlus(DT_UBYTE* compr_addr, DT_SLONG* compr_len, const DT_UBYTE* raw_addr, DT_SLONG raw_len, DT_ID_SWORD level)
{
	if ((raw_addr == NULL) || (compr_addr == NULL) || (raw_len < 1) || (*compr_len < 1)) return 0;

	uLongf tmp_compr_len = (uLongf)(*compr_len);
	DT_SWORD ret = (compress2(compr_addr, &tmp_compr_len, raw_addr, raw_len, level) == Z_OK);
	//DT_SWORD ret = (compress(compr_addr, &tmp_compr_len, raw_addr, raw_len) == Z_OK);

	if (tmp_compr_len >= DV_PDX_ZLIB_MAXBUFFERSIZE) { *compr_len = 0; return 0; }
	*compr_len = (DT_SLONG)tmp_compr_len;

	if (ret) return 1;
	return 0;
}


DT_SWORD pdxZLIBCompress(DT_UBYTE* compr_addr, DT_SLONG* compr_len, const DT_UBYTE* raw_addr, DT_SLONG raw_len)
{
	return pdxZLIBCompressPlus(compr_addr, compr_len, raw_addr, raw_len, Z_DEFAULT_COMPRESSION);
}


DT_SWORD pdxZLIBDecompress(DT_UBYTE* raw_addr, DT_SLONG* raw_len, const DT_UBYTE* compr_addr, DT_SLONG compr_len)
{
	if ((raw_addr == NULL) || (compr_addr == NULL) || (compr_len < 1) || (*raw_len < 1)) return 0;

	uLongf tmp_raw_len = (uLongf)(*raw_len);
	DT_SWORD ret = (uncompress(raw_addr, &tmp_raw_len, compr_addr, compr_len) == Z_OK);

	if (tmp_raw_len >= DV_PDX_ZLIB_MAXBUFFERSIZE) { *raw_len = 0; return 0; }
	*raw_len = (DT_SLONG)tmp_raw_len;

	if (ret) return 1;
	return 0;
}
