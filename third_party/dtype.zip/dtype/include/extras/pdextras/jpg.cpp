/*
 * Basic JPEG support for D-Type Power Engine
 * Copyright (C) 1996-2017 D-Type Solutions
 * Web Site: http://www.d-type.com
 * E-mail: info@d-type.com
 */


#include "jpg/jpeglib.h"

/* <setjmp.h> is used for the optional error recovery mechanism */
#include <setjmp.h>


#define PDX_JPG_OUTPUT_BUFF_SIZE 4096

typedef struct
{
	jpeg_destination_mgr pub; /* public fields */
	JOCTET buffer[PDX_JPG_OUTPUT_BUFF_SIZE]; /* buffer */

	DT_PDX_USER_STREAM* user_stream;

} DT_PDX_JPG_DESTINATION_MGR;


typedef struct
{
	jpeg_error_mgr pub; /* "public" fields */
	jmp_buf setjmp_buffer; /* for return to caller */

} DT_PDX_JPG_ERROR_MGR;

typedef DT_PDX_JPG_ERROR_MGR*DT_PDX_JPG_ERROR_PTR;


METHODDEF(void) pdxJPGInitDestination(j_compress_ptr cinfo)
{
	DT_PDX_JPG_DESTINATION_MGR* dest = (DT_PDX_JPG_DESTINATION_MGR*)cinfo->dest;

	//dest->buffer = (JOCTET*)DF_PDX_MEM_ALLOC(PDX_JPG_OUTPUT_BUFF_SIZE);
	dest->pub.next_output_byte = dest->buffer;
	dest->pub.free_in_buffer = PDX_JPG_OUTPUT_BUFF_SIZE;
}


METHODDEF(boolean) pdxJPGEmptyOutputBuffer(j_compress_ptr cinfo)
{
	DT_PDX_JPG_DESTINATION_MGR* dest = (DT_PDX_JPG_DESTINATION_MGR*)cinfo->dest;

	dest->user_stream->UserFunc(dest->user_stream->UserStruct, dest->buffer, PDX_JPG_OUTPUT_BUFF_SIZE);
	dest->pub.next_output_byte = dest->buffer;
	dest->pub.free_in_buffer = PDX_JPG_OUTPUT_BUFF_SIZE;

	return TRUE;
}


METHODDEF(void) pdxJPGTermDestination(j_compress_ptr cinfo)
{
	DT_PDX_JPG_DESTINATION_MGR* dest = (DT_PDX_JPG_DESTINATION_MGR*)cinfo->dest;
	size_t datacount = PDX_JPG_OUTPUT_BUFF_SIZE - dest->pub.free_in_buffer;

	if (datacount > 0) dest->user_stream->UserFunc(dest->user_stream->UserStruct, dest->buffer, datacount);
}


void pdxJPGMemoryDest(j_compress_ptr cinfo, DT_PDX_USER_STREAM* user_stream)
{
	DT_PDX_JPG_DESTINATION_MGR* dest;

	if (cinfo->dest == NULL)
	{
		cinfo->dest = (jpeg_destination_mgr*)(*cinfo->mem->alloc_small)((j_common_ptr)cinfo, JPOOL_PERMANENT, sizeof(DT_PDX_JPG_DESTINATION_MGR));
	}

	dest = (DT_PDX_JPG_DESTINATION_MGR*)cinfo->dest;
	dest->pub.init_destination = pdxJPGInitDestination;
	dest->pub.empty_output_buffer = pdxJPGEmptyOutputBuffer;
	dest->pub.term_destination = pdxJPGTermDestination;

	dest->pub.next_output_byte = 0;
	dest->pub.free_in_buffer = 0;

	dest->user_stream = user_stream;
}


DT_SLONG pdxJPGMake(DT_UBYTE* bmp_ptr, DT_SWORD format, DT_SWORD /*subformat*/, DT_SLONG wcl, DT_SLONG hcl, DT_UBYTE orientation, DT_SLONG padding, DT_SLONG quality, DT_FILE_PTR file_ptr, DT_PDX_USER_STREAM* user_stream)
{
	DT_SLONG i = 0, ret = 0, y = 0, dy = 1;

	/* JSAMPLEs per row in image_buffer (physical row width in image buffer) */
	DT_SLONG bpr;

	/* pointer to JSAMPLE row[s] */
	JSAMPROW* row_ptr;

	/*
	 * This struct contains the JPEG compression parameters and pointers to
	 * working space (which is allocated as needed by the JPEG library).
	 * It is possible to have several such structures, representing multiple
	 * compression/decompression processes, in existence at once.	We refer
	 * to any one struct (and its associated working data) as a "JPEG object".
	 */
	jpeg_compress_struct cinfo;

	/*
	 * This struct represents a JPEG error handler.	It is declared separately
	 * because applications often want to supply a specialized error handler
	 * (see the second half of this file for an example).	But here we just
	 * take the easy way out and use the standard error handler, which will
	 * print a message on stderr and call exit() if compression fails.
	 * Note that this struct must live as long as the main JPEG parameter
	 * struct, to avoid dangling-pointer problems.
	 */
	jpeg_error_mgr jerr;

	/* Step 1: allocate and initialize JPEG compression object */

	/*
	 * We have to set up the error handler first, in case the initialization
	 * step fails.	(Unlikely, but it could happen if you are out of memory.)
	 * This routine fills in the contents of struct jerr, and returns jerr's
	 * bmp_ptress which we place into the link field in cinfo.
	 */
	cinfo.err = jpeg_std_error(&jerr);

	/* Now we can initialize the JPEG compression object. */
	jpeg_create_compress(&cinfo);

	/* Step 2: specify data destination (eg, a file) */
	/* Note: steps 2 and 3 can be done in either order. */

	if (file_ptr != NULL) jpeg_stdio_dest(&cinfo, file_ptr); else pdxJPGMemoryDest(&cinfo, user_stream);

	/* Step 3: set parameters for compression */

	/*
	 * First we supply a description of the input image.
	 * Four fields of the cinfo struct must be filled in:
	 */
	cinfo.image_width = wcl; /* image width and height, in pixels */
	cinfo.image_height = hcl;

	bpr = wcl;
	if (format == 24)
	{
		bpr *= 3;
		cinfo.input_components = 3;     /* # of color components per pixel */
		cinfo.in_color_space = JCS_RGB; /* colorspace of input image */
	}
	else if (format == 8)
	{
		cinfo.input_components = 1;           /* # of color components per pixel */
		cinfo.in_color_space = JCS_GRAYSCALE; /* colorspace of input image */
	}
	else
	{
		jpeg_destroy_compress(&cinfo);
		return 0;
	}

	/*
	 * Now use the library's routine to set default compression parameters.
	 * (You must set at least cinfo.in_color_space before calling this,
	 * since the defaults depend on the source color space.)
	 */
	jpeg_set_defaults(&cinfo);

	/*
	 * Now you can set any non-default parameters you wish to.
	 * Here we just illustrate the use of quality (quantization table) scaling:
	 */
	jpeg_set_quality(&cinfo, quality, TRUE /* limit to baseline-JPEG values */);

	/* Step 4: Start compressor */

	/*
	 * TRUE ensures that we will write a complete interchange-JPEG file.
	 * Pass TRUE unless you are very sure of what you're doing.
	 */
	jpeg_start_compress(&cinfo, TRUE);

	/* Step 5: while (scan lines remain to be written) */
	/*					 jpeg_write_scanlines(...); */

	if ((row_ptr = (JSAMPROW*)DF_PDX_MEM_ALLOC(hcl * sizeof(JSAMPROW))) != NULL)
	{
		if (orientation == 1) { y = hcl - 1; dy = -1; }

		for (i = 0; i < hcl; i++, y += dy, bmp_ptr += bpr + padding)
		{
			row_ptr[y] = (JSAMPLE*)bmp_ptr;

#ifdef IMAGE_ROW_DEBUG
			IMAGE_ROW_DEBUG(format, 0 /*subformat*/, wcl, hcl, bmp_ptr, y);
#endif
		}

		jpeg_write_scanlines(&cinfo, row_ptr, hcl);

		DF_PDX_MEM_FREE(row_ptr);

		ret = 1;
	}


	/* Step 6: Finish compression */

	jpeg_finish_compress(&cinfo);

	/* Step 7: release JPEG compression object */

	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_compress(&cinfo);

	return ret;
}


/* Here's the routine that will replace the standard error_exit method */
METHODDEF(void) pdxJPGErrorExit(j_common_ptr cinfo)
{
	/* cinfo->err really points to a DT_PDX_JPG_ERROR_MGR struct, so coerce pointer */
	DT_PDX_JPG_ERROR_PTR myerr = (DT_PDX_JPG_ERROR_PTR)cinfo->err;

	/* Always display the message. */
	/* We could postpone this until after returning, if we chose. */
	(*cinfo->err->output_message)(cinfo);

	/* Return control to the setjmp point */
	longjmp(myerr->setjmp_buffer, 1);
}


DT_SLONG pdxJPGLoad(DT_UBYTE** bmp_ptr, DT_SWORD* format, DT_SLONG* wcl, DT_SLONG* hcl, DT_UBYTE orientation, DT_FILE_PTR file_ptr)
{
	DT_SLONG i = 0, ret = 0, y = 0, dy = 1;
	DT_SLONG bpr;
	DT_UBYTE* ptr;

	jpeg_decompress_struct cinfo;
	DT_PDX_JPG_ERROR_MGR jerr;

	*format = 0;
	*bmp_ptr = NULL;

	/* Step 1: allocate and initialize JPEG compression object */
	//cinfo.err = jpeg_std_error(&jerr);
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = pdxJPGErrorExit;

	/* Establish the setjmp return context for pdxJPGErrorExit to use. */
	if (setjmp(jerr.setjmp_buffer))
	{
		/* If we get here, the JPEG code has signaled an error. We need to clean up the JPEG object and return. */
		jpeg_destroy_decompress(&cinfo);
		return 0;
	}

	/* Now we can initialize the JPEG decompression object. */
	jpeg_create_decompress(&cinfo);

	/* Step 2: specify data source (eg, a file) */
	jpeg_stdio_src(&cinfo, file_ptr);

	/* Step 3: read file parameters with jpeg_read_header() */
	jpeg_read_header(&cinfo, TRUE);

	/* Step 4: set parameters for decompression */
	/* Here, we don't need to change any of the defaults set by jpeg_read_header(), so we do nothing here. */

	/* Step 5: Start decompressor */
	jpeg_start_decompress(&cinfo);

	/* JSAMPLEs per row in output buffer */
	*wcl = cinfo.output_width; 	/* image width and height, in pixels */
	*hcl = cinfo.output_height;
	bpr = *wcl * cinfo.output_components;


	if (cinfo.output_components == 3) *format = 24; else if (cinfo.output_components == 1) *format = 8;


	if (*format != 0)
	{
		*bmp_ptr = (DT_UBYTE*)DF_PDX_MEM_ALLOC(*hcl * bpr);

		if (*bmp_ptr != NULL)
		{
			if (orientation == 1) { y = *hcl - 1; dy = -1; }

			/* Step 6: */
			/* while (scan lines remain to be read) */
			/* jpeg_read_scanlines(...); */

			//while (cinfo.output_scanline < cinfo.output_height)
			for (i = 0; i < *hcl; i++, y += dy)
			{
				ptr = *bmp_ptr + y * bpr;
				jpeg_read_scanlines(&cinfo, &ptr, 1);
			}


			/* Step 7: Finish decompression */
			jpeg_finish_decompress(&cinfo);

			ret = 1;
		}
	}

	/* Step 8: Release JPEG decompression object */
	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_decompress(&cinfo);

	return ret;
}
