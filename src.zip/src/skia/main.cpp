#include <cassert>
#include <iostream>
using namespace std;

#ifdef WIN32
char* strInputPng = "d:/111.png";
char* strOutputPng = "d:/333.png";
#else
char* strInputPng = "/tmp/111.png";
char* strOutputPng = "/tmp/333.png";
#endif

#include "TextEngineLib.h"
using namespace TextEngine;
#include "SDLWindow.h"

extern int GetExecutePath(char* , int );

//#define TEST_SKIA
#ifdef TEST_SKIA
#include "SkBitmap.h"
#include "SkPaint.h"
#include "SkCanvas.h"
#include "SkPath.h"
#include "SkRect.h"
#include "SkImageEncoder.h"
#endif // TEST_SKIA

int main(int argc, char** argv)
{
#ifdef TEST_SKIA
    int screen_w = 400;
    int screen_h = 400;

    SkBitmap bitmap;
    SkImageInfo ii = SkImageInfo::Make(screen_w, screen_h, kBGRA_8888_SkColorType, kPremul_SkAlphaType);
    bitmap.allocPixels(ii);

    SkCanvas can(bitmap);
    SkPath sk;
    sk.moveTo(100,100);
    sk.lineTo(300,200);
    sk.lineTo(200,100);
    sk.close();

    bool bb =  sk.isEmpty();
    bb = sk.isFinite();

    SkPaint paint;
    paint.setStyle(SkPaint::kStroke_Style);
    paint.setColor(0xff1f78b4);
    paint.setStrokeWidth(8);
    paint.setAntiAlias(true);
    can.drawPath(sk,paint);

    SDLWindow SDLWin;
	SDLWin.Init(screen_w, screen_h);
	SDLWin.Update(static_cast<const char*>(bitmap.getPixels()));
	SDLWin.EventLoop();
#else
	char szExecutePath[512] = { 0 };
	int iRet = GetExecutePath(szExecutePath, sizeof(szExecutePath));
	assert(iRet == 0);
	string strFontsPath = szExecutePath;
	strFontsPath.append("fonts/");

	IFontEngine* pFontEngine = TextUtil::GetFontEngine();
	pFontEngine->LoadFonts(strFontsPath.c_str());

	ITextImage* pImage = nullptr;
	TextUtil::CreateTextImage(&pImage);
	pImage->LoadFile(strInputPng);
	//pImage->Alloc(200, 200, 32);
	//pImage->FillColor(0xFF00FFFF);
	pImage->SaveFile(strOutputPng);

	ITextElement* pTextElement1 = nullptr;
	TextUtil::CreateTextElement(&pTextElement1);
	pTextElement1->SetText("Text Engine Test !\rHI");
	pTextElement1->SetColor(0xFFFFFF00);
	//ITextImage* pTextImage = pTextElement1->TextImage();
	pTextElement1->SetFontSize(10);
	pTextElement1->SetAdaptiveSize(1920, 1080);
	ITextImage* pTextImage = pTextElement1->TextImage();
	cout << pTextImage->GetWidth() << "x" << pTextImage->GetHeight() << " - "
		<< pTextImage->GetPitch() << endl;

	// show image in the window
	SDLWindow SDLWin;
	SDLWin.Init(pTextImage->GetWidth(), pTextImage->GetHeight());
	SDLWin.Update(pTextImage->GetBits());
	SDLWin.EventLoop();

	pTextImage->SaveFile(strOutputPng);
	pTextElement1->Release();
#endif // 0
	return 0;
}
