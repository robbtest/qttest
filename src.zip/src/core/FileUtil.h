#pragma once

#include <string>

// 
class CFileUtil
{
public:
	static bool IsFileExist(char* pPathBuf);

protected:
	CFileUtil();
	~CFileUtil();
};
