#include "DTypeTextRender.h"
#include "TextImage.h"
#include "DTypeFontEngine.h"
#include "MacroDefine.h"
#include "TextDataDefine.h"
#include "dtshapes.h"

#define BLOD_DEFALUT_VALUE	    2
#define ITALIC_DEFALUT_VALUE	-12

int CDTypeTextRender::DrawCharFace(CTextImage* pImage, const TCharLayoutInfo& sCharLayoutInfo, const TextFont& sTextFont)
{
	CHECK_RETURN_RET(sCharLayoutInfo.iCharIndex == 0, 1);
	CHECK_RETURN_RET(!sTextFont.bNotNull, 2);

	DT_DTENGINE hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	DT_MDC	sMdc;
	sMdc.w = pImage->GetWidth();
	sMdc.h = -pImage->GetHeight();
	sMdc.l = pImage->GetBitCount();
	sMdc.m = (DT_UBYTE*)pImage->GetBits();
	dtOutputSetAsMDC(hEngine, DV_FORMAT_32, 3, &sMdc, 0, 0, pImage->GetWidth(), pImage->GetHeight());

	int iEffectsIndex = 0;
	// DT_STYLE_ATTRIBS
	DT_STYLE_ATTRIBS sStyleAttribs = { { 0, 0 }, { 255, 0, 0, 0 }, 0, NULL };
	sStyleAttribs.rgbt[0] = GET_R_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[1] = GET_G_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[2] = GET_B_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[3] = 255 - GET_A_VALUE(sTextFont.iColor);
	// DT_STYLE_EFFECTS
	DT_STYLE_EFFECTS sStyleEffects = { 0, { DV_EFFECT_NONE, 0, 0 }, { 0, 255, 0, 0 }, NULL };
	sStyleEffects.rgbt[0] = GET_R_VALUE(sTextFont.iColor);
	sStyleEffects.rgbt[1] = GET_G_VALUE(sTextFont.iColor);
	sStyleEffects.rgbt[2] = GET_B_VALUE(sTextFont.iColor);
	sStyleEffects.rgbt[3] = 255 - GET_A_VALUE(sTextFont.iColor);
	if (sTextFont.bBold)
	{
		sStyleEffects.effects_arr[iEffectsIndex] = DV_EFFECT_HVBOLD;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
	}
	sStyleEffects.effects_len = iEffectsIndex;
	// DT_TYPE_ATTRIBS
	DT_TYPE_ATTRIBS  sTypeAttribs = { 0 };
	sTypeAttribs.font_index = sCharLayoutInfo.iFontIndex;
	sTypeAttribs.transform.params.size_h = sCharLayoutInfo.sCharSize.iWidth;
	sTypeAttribs.transform.params.size_v = sCharLayoutInfo.sCharSize.iHeight;
	sTypeAttribs.transform.params.skew_h = sTextFont.bItalic ? ITALIC_DEFALUT_VALUE : 0;
	sTypeAttribs.transform.params.skew_v = 0;
	sTypeAttribs.transform.params.rotation = 0;
	// Render char 
	dtOutputSetStyleAttribs(hEngine, &sStyleAttribs, 0);
	dtOutputSetStyleEffects(hEngine, &sStyleEffects, 0);
	dtTypesetterSetTypeAttribs(hEngine, &sTypeAttribs, 0);
	dtGlyphDoOutput(hEngine, sCharLayoutInfo.iCharIndex, sCharLayoutInfo.sOrigin.iX, sCharLayoutInfo.sOrigin.iY, 0, nullptr);

	return 0;
}

int CDTypeTextRender::DrawCharBorder(CTextImage* pImage, const TCharLayoutInfo& sCharLayoutInfo, const TextFont& sTextFont, const TextBorder& sTextBorder)
{
	CHECK_RETURN_RET(sCharLayoutInfo.iCharIndex == 0, 1);
	CHECK_RETURN_RET(!sTextBorder.bNotNull || !sTextBorder.bEnable, 1);

	DT_DTENGINE hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	DT_MDC	sMdc;
	sMdc.w = pImage->GetWidth();
	sMdc.h = -pImage->GetHeight();
	sMdc.l = pImage->GetBitCount();
	sMdc.m = (DT_UBYTE*)pImage->GetBits();
	dtOutputSetAsMDC(hEngine, DV_FORMAT_32, 3, &sMdc, 0, 0, pImage->GetWidth(), pImage->GetHeight());

	int iEffectsIndex = 0;
	// DT_STYLE_ATTRIBS
	DT_STYLE_ATTRIBS sStyleAttribs = { { 0, 0 }, { 255, 0, 0, 0 }, 0, NULL };
	sStyleAttribs.rgbt[0] = GET_R_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[1] = GET_G_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[2] = GET_B_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[3] = 255 - GET_A_VALUE(sTextFont.iColor);
	// DT_STYLE_EFFECTS
	DT_STYLE_EFFECTS sStyleEffects = { 0, { DV_EFFECT_NONE, 0, 0 }, { 0, 255, 0, 0 }, NULL };
	sStyleEffects.rgbt[0] = GET_R_VALUE(sTextBorder.iColor1);
	sStyleEffects.rgbt[1] = GET_G_VALUE(sTextBorder.iColor1);
	sStyleEffects.rgbt[2] = GET_B_VALUE(sTextBorder.iColor1);
	sStyleEffects.rgbt[3] = 255 - sTextBorder.iAlpha;
	if (sTextFont.bBold)
	{
		sStyleEffects.effects_arr[iEffectsIndex] = DV_EFFECT_HVBOLD;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
	}
	if (sTextBorder.iBlurRadius > 0)
	{
		sStyleEffects.effects_arr[iEffectsIndex] = DV_EFFECT_HVBLUR_GAUSS;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = sTextBorder.iBlurRadius * 2;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = sTextBorder.iBlurRadius * 2;;
		iEffectsIndex++;
	}
	sStyleEffects.effects_len = iEffectsIndex;
	// DT_TYPE_ATTRIBS
	DT_TYPE_ATTRIBS  sTypeAttribs = { 0 };
	sTypeAttribs.font_index = sCharLayoutInfo.iFontIndex;
	sTypeAttribs.transform.params.size_h = sCharLayoutInfo.sCharSize.iWidth;
	sTypeAttribs.transform.params.size_v = sCharLayoutInfo.sCharSize.iHeight;
	sTypeAttribs.transform.params.skew_h = sTextFont.bItalic ? ITALIC_DEFALUT_VALUE : 0;;
	sTypeAttribs.transform.params.skew_v = 0;
	sTypeAttribs.transform.params.rotation = 0;
	sTypeAttribs.thickness = static_cast<DT_SLONG>(((sTextBorder.iSize + 3) * 50.0f));
	dtOutputSetStyleAttribs(hEngine, &sStyleAttribs, 0);
	dtOutputSetStyleEffects(hEngine, &sStyleEffects, 0);
	dtTypesetterSetTypeAttribs(hEngine, &sTypeAttribs, 0);
	dtGlyphDoOutput(hEngine, sCharLayoutInfo.iCharIndex, sCharLayoutInfo.sOrigin.iX, sCharLayoutInfo.sOrigin.iY, 0, nullptr);

	return 0;
}

int CDTypeTextRender::DrawCharShadow(CTextImage* pImage, const TCharLayoutInfo& sCharLayoutInfo, const TextFont& sTextFont, const TextShadow& sTextShadow)
{
	CHECK_RETURN_RET(sCharLayoutInfo.iCharIndex == 0, 1);
	CHECK_RETURN_RET(!sTextShadow.bNotNull || !sTextShadow.bEnable, 1);

	
	DT_DTENGINE hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	DT_MDC	sMdc;
	sMdc.w = pImage->GetWidth();
	sMdc.h = -pImage->GetHeight();
	sMdc.l = pImage->GetBitCount();
	sMdc.m = (DT_UBYTE*)pImage->GetBits();
	dtOutputSetAsMDC(hEngine, DV_FORMAT_32, 3, &sMdc, 0, 0, pImage->GetWidth(), pImage->GetHeight());

	int iEffectsIndex = 0;
	// DT_STYLE_ATTRIBS
	DT_STYLE_ATTRIBS sStyleAttribs = { { 0, 0 }, { 255, 0, 0, 0 }, 0, NULL };
	sStyleAttribs.rgbt[0] = GET_R_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[1] = GET_G_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[2] = GET_B_VALUE(sTextFont.iColor);
	sStyleAttribs.rgbt[3] = 255 - GET_A_VALUE(sTextFont.iColor);
	DT_STYLE_EFFECTS sStyleEffects = { 0, { DV_EFFECT_NONE, 0, 0 }, { 0, 255, 0, 0 }, NULL };
	sStyleEffects.rgbt[0] = GET_R_VALUE(sTextShadow.iColor);
	sStyleEffects.rgbt[1] = GET_G_VALUE(sTextShadow.iColor);
	sStyleEffects.rgbt[2] = GET_B_VALUE(sTextShadow.iColor);
	sStyleEffects.rgbt[3] = 255 - sTextShadow.iAlpha;
	if (sTextFont.bBold)
	{
		sStyleEffects.effects_arr[iEffectsIndex] = DV_EFFECT_HVBOLD;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = BLOD_DEFALUT_VALUE;
		iEffectsIndex++;
	}
	if (sTextShadow.iBlurRadius > 0)
	{
		sStyleEffects.effects_arr[iEffectsIndex] = DV_EFFECT_HVBLUR_GAUSS;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = sTextShadow.iBlurRadius * 2;
		iEffectsIndex++;
		sStyleEffects.effects_arr[iEffectsIndex] = sTextShadow.iBlurRadius * 2;;
		iEffectsIndex++;
	}
	sStyleEffects.effects_len = iEffectsIndex;
	DT_TYPE_ATTRIBS  sTypeAttribs = { 0 };
	sTypeAttribs.font_index = sCharLayoutInfo.iFontIndex;
	sTypeAttribs.transform.params.size_h = sCharLayoutInfo.sCharSize.iWidth;
	sTypeAttribs.transform.params.size_v = sCharLayoutInfo.sCharSize.iHeight;
	sTypeAttribs.transform.params.skew_h = sTextFont.bItalic ? ITALIC_DEFALUT_VALUE : 0;
	sTypeAttribs.transform.params.skew_v = 0;
	sTypeAttribs.transform.params.rotation = 0;
	dtOutputSetStyleAttribs(hEngine, &sStyleAttribs, 0);
	dtOutputSetStyleEffects(hEngine, &sStyleEffects, 0);
	dtTypesetterSetTypeAttribs(hEngine, &sTypeAttribs, 0);
	DT_FLOAT dtfX = sCharLayoutInfo.sOrigin.iX + sTextShadow.iDistance;
	DT_FLOAT dtfY = sCharLayoutInfo.sOrigin.iY + sTextShadow.iDistance;
	dtGlyphDoOutput(hEngine, sCharLayoutInfo.iCharIndex, dtfX, dtfY, 0, nullptr);

	return 0;
}

int CDTypeTextRender::DrawCharBackgrounp(CTextImage* pImage, const TCharLayoutInfo& sCharLayoutInfo, const TextFont& sTextFont)
{
	CHECK_RETURN_RET(sCharLayoutInfo.iCharIndex == 0, 1);

	DT_DTENGINE hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	DT_MDC	sMdc;
	sMdc.w = pImage->GetWidth();
	sMdc.h = -pImage->GetHeight();
	sMdc.l = pImage->GetBitCount();
	sMdc.m = (DT_UBYTE*)pImage->GetBits();
	dtOutputSetAsMDC(hEngine, DV_FORMAT_32, 3, &sMdc, 0, 0, pImage->GetWidth(), pImage->GetHeight());

	int iEffectsIndex = 0;
	// DT_STYLE_ATTRIBS
	DT_STYLE_ATTRIBS sStyleAttribs = { { 0, 0 }, { 255, 0, 0, 0 }, 0, NULL };
	sStyleAttribs.rgbt[0] = GET_R_VALUE(sTextFont.iBgColor);
	sStyleAttribs.rgbt[1] = GET_G_VALUE(sTextFont.iBgColor);
	sStyleAttribs.rgbt[2] = GET_B_VALUE(sTextFont.iBgColor);
	sStyleAttribs.rgbt[3] = 255 - GET_A_VALUE(sTextFont.iBgColor);
	dtOutputSetStyleAttribs(hEngine, &sStyleAttribs, 0);
#if 0
	dtsRectangleFilled(hEngine, (DT_SLONG)sCharLayoutInfo.sOrigin.iX, (DT_SLONG)(sCharLayoutInfo.sOrigin.iY - sCharLayoutInfo.iAscent), 
		0, 0, sCharLayoutInfo.sAdvance.iWidth, sCharLayoutInfo.sAdvance.iHeight, 0, NULL);
#else
	dtsRectangleFilled(hEngine, (DT_SLONG)sCharLayoutInfo.sOrigin.iX, (DT_SLONG)(sCharLayoutInfo.sOrigin.iY - sCharLayoutInfo.iMaxAscent), 
		0, 0, sCharLayoutInfo.sAdvance.iWidth, sCharLayoutInfo.iMaxAscent + sCharLayoutInfo.iMaxDecent, 0, NULL);
#endif
	

	return 0;
}