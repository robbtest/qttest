#include "TextImage.h"
#include "MacroDefine.h"

#include <cassert>
#include <cstdlib>
#include <cstring>

CTextImageInit::CTextImageInit()
{
	FreeImage_Initialise(TRUE);
}

CTextImageInit::~CTextImageInit()
{
	FreeImage_DeInitialise();
}

CTextImageInit g_StaticTexImageInit;

CTextImage::CTextImage()
{

}

CTextImage::~CTextImage()
{
	if (m_pFBitmap != nullptr)
	{
		FreeImage_Unload(m_pFBitmap);
		m_pFBitmap = nullptr;
	}
}

void __stdcall CTextImage::Release()
{
    delete this;
}

int __stdcall CTextImage::Alloc(uint32_t uWidth, uint32_t uHeight, uint32_t nBitCount)
{
	CHECK_RETURN_RET(uWidth == 0, 1);
	CHECK_RETURN_RET(uHeight == 0, 1);
	CHECK_RETURN_RET(nBitCount == 0, 1);
	CHECK_RETURN_RET(uWidth == GetWidth() && uHeight == GetHeight() && nBitCount == GetBitCount(), 1);

	if (m_pFBitmap != nullptr)
	{
		FreeImage_Unload(m_pFBitmap);
		m_pFBitmap = nullptr;
	}
    m_pFBitmap = FreeImage_AllocateT(FREE_IMAGE_TYPE::FIT_BITMAP, uWidth, uHeight, nBitCount);

	return m_pFBitmap != nullptr ? 0 : 2;
}

ITextImage*	__stdcall CTextImage::Clone()
{
	CTextImage* pTextImage = new CTextImage();
	if (pTextImage != nullptr)
	{
		pTextImage->m_pFBitmap = FreeImage_Clone(m_pFBitmap);
	}

	return static_cast<ITextImage*>(pTextImage);
}

int __stdcall CTextImage::GetWidth()
{
	int iWidth = 0;
	if (m_pFBitmap)
	{
		iWidth = FreeImage_GetWidth(m_pFBitmap);
	}
	return iWidth;
}

int __stdcall CTextImage::GetHeight()
{
	int iHeight = 0;
	if (m_pFBitmap)
	{
		iHeight = FreeImage_GetHeight(m_pFBitmap);
	}
	return iHeight;
}

int __stdcall CTextImage::GetPitch()
{
	int iPitch = 0;
	if (m_pFBitmap)
	{
		iPitch = FreeImage_GetPitch(m_pFBitmap);
	}
	return iPitch;
}

int __stdcall CTextImage::GetBitCount()
{
	int iBitCount = 0;
	if (m_pFBitmap)
	{
		iBitCount = FreeImage_GetBPP(m_pFBitmap);
	}
	return iBitCount;
}

const char* __stdcall CTextImage::GetBits()
{
	CHECK_RETURN_RET(m_pFBitmap == nullptr, nullptr);

	return reinterpret_cast<const char*>(FreeImage_GetBits(m_pFBitmap));
}

void __stdcall CTextImage::FillColor(uint32_t uColor)
{
	RGBQUAD  color = { 0 };
	color.rgbRed = (uColor >> 16) & 0xFF;
	color.rgbBlue = (uColor >> 8) & 0xFF;
	color.rgbGreen = uColor & 0xFF;

	FreeImage_SetBackgroundColor(m_pFBitmap, &color);
}

void __stdcall CTextImage::FillImage(ITextImage* pImage)
{
	assert(false);
}

int __stdcall CTextImage::LoadFile(const char* pFileName)
{
	FIBITMAP*         pFBitmap = nullptr;
	FREE_IMAGE_FORMAT emFormat = GetFreeImageFormat(pFileName);
	if (emFormat != FIF_UNKNOWN && FreeImage_FIFSupportsReading(emFormat))
	{
		pFBitmap = FreeImage_Load(emFormat, pFileName, PNG_DEFAULT);
	}
	if (pFBitmap != nullptr)
	{
		unsigned uBitCount = FreeImage_GetBPP(pFBitmap);
		if (uBitCount != 32)
		{
			FIBITMAP* pFBitmapTmp = pFBitmap;
			pFBitmap = FreeImage_ConvertTo32Bits(pFBitmap);
			FreeImage_Unload(pFBitmapTmp);
		}
		assert(FreeImage_FlipVertical(pFBitmap) ? true : false);
	}
	if (pFBitmap != nullptr)
	{
		if (m_pFBitmap != nullptr)
		{
			FreeImage_Unload(m_pFBitmap);
			m_pFBitmap = nullptr;
		}
		m_pFBitmap = pFBitmap;
	}
	
	return pFBitmap != nullptr ? 0 : 2;
}

int __stdcall CTextImage::SaveFile(const char* pFileName)
{
	if (pFileName == nullptr) return 1;
	if (m_pFBitmap == nullptr) return 2;

	FIBITMAP* pFBitmap = FreeImage_Clone(m_pFBitmap);
	assert(FreeImage_FlipVertical(pFBitmap) ? true : false);

	const char* pDot = std::strrchr(pFileName, '.');
	assert(pDot != nullptr);
	pDot = pDot + 1;
	const char* formatArr[] = { "image/bmp", "image/jpg", "image/jp2", "image/j2k", "image/png" };
	int uSize = sizeof(formatArr) / sizeof(formatArr[0]);
	int iFormatIndex = 0;
	for (int i = 0; i < uSize; i++)
	{
		if (std::strstr(formatArr[i], pDot) != nullptr)
		{
			iFormatIndex = i;
			break;
		}
	}

	FREE_IMAGE_FORMAT emFormatArr[] = { FIF_BMP, FIF_JPEG, FIF_JP2, FIF_J2K, FIF_PNG };
	int uFormatSize = sizeof(emFormatArr) / sizeof(emFormatArr[0]);
	assert(uSize == uFormatSize);
	FREE_IMAGE_FORMAT emCurFormat = emFormatArr[iFormatIndex];
	bool bSaved = FreeImage_Save(emCurFormat, pFBitmap, pFileName) ? true : false;
	FreeImage_Unload(pFBitmap);

	return bSaved ? 0 : 1;
}

FREE_IMAGE_FORMAT CTextImage::GetFreeImageFormat(const char *filePath)
{
	FREE_IMAGE_FORMAT emFormat = FIF_UNKNOWN;

	emFormat = FreeImage_GetFileType(filePath, 0);
	if (emFormat == FIF_UNKNOWN)
	{
		emFormat = FreeImage_GetFIFFromFilename(filePath);
	}

	return emFormat;
}