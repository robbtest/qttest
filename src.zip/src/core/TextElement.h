#pragma once

#ifndef _TEXT_ELEMENT_H_
#define _TEXT_ELEMENT_H_

#include <string>
using std::string;
#include <vector>
#include <mutex>

#include "ITextElement.h"
using namespace TextEngine;

#define DEFAULT_FONT_COLOR	    0xFFFF0000
#define DEFAULT_FONT_SIZE	    20.0

class CTextImage;
class CDTypeTextHLayout;

// 
class CTextElement : public ITextElement
{
public:
	CTextElement();
	virtual ~CTextElement();
	// ITextElement
	virtual void                __stdcall Release();
	virtual void                __stdcall SetAdaptiveSize(int iWidth, int iHeight);
	virtual void                __stdcall SetText(const char* szText);
	virtual const char*         __stdcall GetText();
	virtual void                __stdcall SetColor(unsigned long uColor);
	virtual unsigned long       __stdcall GetColor();
	virtual void                __stdcall SetFontSize(int iFontSize);
	virtual int                 __stdcall GetFontSize();
	virtual void			    __stdcall SetFontFamily(const char* szFontFamily);
	virtual const char*         __stdcall GetFontFamily();
	virtual void                __stdcall SetFontBold(bool bBold) ;
	virtual bool                __stdcall GetFontBold();
	virtual void                __stdcall SetFontItalic(bool bItalic);
	virtual bool                __stdcall GetFontItalic();
	virtual void                __stdcall SetTextFont(int iIndex, const TextFont& sTextFont);
	virtual TextFont		    __stdcall GetTextFont(int iIndex);
	virtual void                __stdcall SetTextBorder(const TextBorder& sTextBorder, int iIndex = -1);
	virtual TextBorder          __stdcall GetTextBorder(int iIndex);
	virtual void                __stdcall SetTextShadow(const TextShadow& sTextShadow, int iIndex = -1);
	virtual TextShadow          __stdcall GetTextShadow(int iIndex);
	virtual ITextImage*         __stdcall TextImage();
	virtual ITextLayout*        __stdcall TextLayout();
	//
	virtual const double        __stdcall GetFontSizeScale();

protected:
	// 
	virtual const TextInfo      __stdcall GetTextInfo(int iIndex);

private:
	CTextImage*			        m_pTextImage  = nullptr;
	CDTypeTextHLayout*		    m_pTextLayout = nullptr;
	string				        m_strText;
	string				        m_strFontFamily;
	int					        m_iColor      = DEFAULT_FONT_COLOR;
	double				        m_dFontSize   = DEFAULT_FONT_SIZE;
	double                      m_dScale      = 1.0;
	bool                        m_bBold       = false;
	bool                        m_bItalic     = false;
	TextBorder                  m_sTextBorder;
	TextShadow	                m_sTextShadow;
	TextInfoVec                 m_TextInfoVec;
};

#endif // _TEXT_ELEMENT_H_