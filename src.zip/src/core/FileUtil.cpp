#include "FileUtil.h"
#include <cassert>
#include <cstring>

#ifdef WIN32
    #include <windows.h>
#elif  LINUX
    #include <unistd.h>
#elif  MACOS
    
#else
#endif


bool CFileUtil::IsFileExist(char* pPathBuf)
{
	assert(pPathBuf != nullptr);

	bool  bRet = false;

#ifdef WIN32

#elif  LINUX

#elif  MACOS

#else

#endif

	return bRet;
}

CFileUtil::CFileUtil()
{

}
