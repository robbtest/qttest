#pragma once

#ifndef _TEXT_IMAGE_H_
#define _TEXT_IMAGE_H_

#include "ITextImage.h"
using namespace TextEngine;
#include "FreeImage.h"

class CTextImageInit
{
public:
	CTextImageInit();
	~CTextImageInit();
};

// 
class CTextImage : public ITextImage
{
public:
	CTextImage();
	virtual ~CTextImage();
	// ITextImage
	virtual void        __stdcall Release();
	virtual int         __stdcall Alloc(uint32_t uWidth, uint32_t uHeight, uint32_t nBitCount);
	virtual ITextImage*	__stdcall Clone();

	virtual int			__stdcall GetWidth();
	virtual int         __stdcall GetHeight();
	virtual int         __stdcall GetPitch();
	virtual int         __stdcall GetBitCount();
	virtual const char* __stdcall GetBits();

	virtual void        __stdcall FillColor(uint32_t uColor);
	virtual void        __stdcall FillImage(ITextImage* pImage);

	virtual int         __stdcall LoadFile(const char* pFileName);
	virtual int         __stdcall SaveFile(const char* pFileName);

protected:
	FREE_IMAGE_FORMAT GetFreeImageFormat(const char *filePath);

private:
	FIBITMAP*		m_pFBitmap = nullptr;
};

#endif // _TEXT_IMAGE_H_