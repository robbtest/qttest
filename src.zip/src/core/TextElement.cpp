#include "TextElement.h"
#include "TextImage.h"
#include "TextHLayout.h"
#include "MacroDefine.h"

#include <cassert>
#include <cstring>

#define TEXT_BASE_WIDTH     640
#define TEXT_BASE_HEIGHT	360

CTextElement::CTextElement()
{
	m_pTextLayout = new CDTypeTextHLayout();
	assert(m_pTextLayout != nullptr);
	m_pTextLayout->Init(this);
	m_pTextImage = new CTextImage();
	assert(m_pTextImage);
	std::memset(&m_sTextBorder, 0, sizeof(TextBorder));
	std::memset(&m_sTextShadow, 0, sizeof(TextShadow));
	m_sTextBorder.bNotNull = true;
	m_sTextShadow.bNotNull = true;
}


CTextElement::~CTextElement()
{
	SAFE_DELETE(m_pTextImage);
	SAFE_DELETE(m_pTextLayout);
	m_TextInfoVec.clear();
}

void __stdcall CTextElement::Release()
{
    delete this;
}

void __stdcall CTextElement::SetAdaptiveSize(int iWidth, int iHeight)
{
	double dfHScale = iWidth  / TEXT_BASE_WIDTH;
	double dVScale = iHeight / TEXT_BASE_HEIGHT;
	m_dScale = dfHScale > dVScale ? dfHScale : dfHScale;
}

void __stdcall CTextElement::SetText(const char* szText)
{
	CHECK_RETURN(szText == nullptr);

	m_strText = szText;
}

const char* __stdcall CTextElement::GetText()
{
	return m_strText.c_str();
}

void __stdcall CTextElement::SetColor(unsigned long uColor)
{
	m_iColor = uColor;
}

unsigned long __stdcall CTextElement::GetColor()
{
	return m_iColor;
}

void __stdcall CTextElement::SetFontSize(int iFontSize)
{
	m_dFontSize = static_cast<double>(iFontSize);
}

int CTextElement::GetFontSize()
{
	return static_cast<int>(m_dFontSize);
}

void __stdcall CTextElement::SetFontFamily(const char* szFontFamily)
{
	CHECK_RETURN(szFontFamily == nullptr);

	m_strFontFamily = szFontFamily;
}

const char* __stdcall CTextElement::GetFontFamily()
{
	return m_strFontFamily.c_str();
}

void __stdcall CTextElement::SetFontBold(bool bBold)
{
	m_bBold = bBold;
}

bool __stdcall CTextElement::GetFontBold()
{
	return m_bBold;
}

void __stdcall CTextElement::SetFontItalic(bool bItalic)
{
	m_bItalic = bItalic;
}

bool __stdcall CTextElement::GetFontItalic()
{
	return m_bItalic;
}

void __stdcall CTextElement::SetTextFont(int iIndex, const TextFont& sTextFont)
{
	CHECK_RETURN(iIndex < 0 || iIndex >= m_strText.size());

	// push empty TextInfo into vector if index is over size of vector
	if (iIndex >= m_TextInfoVec.size())
	{
		TextInfo sTextInfo = { 0 };
		for (std::size_t i = m_TextInfoVec.size(); i <= iIndex; i++)
		{
			m_TextInfoVec.push_back(sTextInfo);
		}
	}
	TextFont& sTextFontRef = m_TextInfoVec[iIndex].sTextFont;
	// set TextFont
	std::memcpy(&sTextFontRef, &sTextFont, sizeof(TextFont));
	sTextFontRef.bNotNull = true;
}

TextFont __stdcall CTextElement::GetTextFont(int iIndex)
{
	TextFont sTextFont = { 0 };

	CHECK_RETURN_RET(iIndex < 0, sTextFont);

	if (iIndex < m_TextInfoVec.size())
	{
		std::memcpy(&sTextFont, &m_TextInfoVec[iIndex].sTextFont, sizeof(TextFont));
	}
	return sTextFont;
}

void __stdcall CTextElement::SetTextBorder(const TextBorder& sTextBorder, int iIndex)
{
	CHECK_RETURN(iIndex > 0 && iIndex >= m_strText.size());

	// push empty TextInfo into vector if index is over size of vector
	int iCount = static_cast<int>(m_TextInfoVec.size());
	assert(iCount >= 0);
	if (iIndex >= iCount)
	{
		TextInfo sTextInfo = { 0 };
		for (int i = iCount; i <= iIndex; i++)
		{
			m_TextInfoVec.push_back(sTextInfo);
		}
	}
	// get TextBorder depend on index and get global TextBorder if index is not among vector
	TextBorder* pTextBorder = (iIndex < 0) ? &m_sTextBorder : &(m_TextInfoVec[iIndex].sTextBorder);
	assert(pTextBorder != nullptr);
	// set TextBorder to right TextBorder
	std::memcpy(pTextBorder, &sTextBorder, sizeof(TextBorder));
	pTextBorder->bNotNull = true;
}

TextBorder __stdcall CTextElement::GetTextBorder(int iIndex)
{
	TextBorder sTextBorder = { 0 };
	if (iIndex >=0 && iIndex < m_TextInfoVec.size())
	{
		const TextBorder* pTextBorder = (iIndex < 0) ? &m_sTextBorder : &(m_TextInfoVec[iIndex].sTextBorder);
		std::memcpy(&sTextBorder, pTextBorder, sizeof(TextBorder));
	}
	return sTextBorder;
}

void __stdcall CTextElement::SetTextShadow(const TextShadow& sTextShadow, int iIndex)
{
	CHECK_RETURN(iIndex > 0 && iIndex >= m_strText.size());

	// get TextShadow directly if exists or push empty TextInfo into vector then get empty TextShadow
	int iCount = static_cast<int>(m_TextInfoVec.size());
	assert(iCount >= 0);
	TextInfo sTextInfo = { 0 };
	if (iIndex >= iCount)
	{
		for (int i = iCount; i <= iIndex; i++)
		{
			m_TextInfoVec.push_back(sTextInfo);
		}
	}
	// get TextShadow depend on index and get global TextShadow if index is not among vector
	TextShadow* pTextShadow = (iIndex < 0) ? &m_sTextShadow : &(m_TextInfoVec[iIndex].sTextShadow);
	assert(pTextShadow != nullptr);
	// set TextShadow to right TextShadow
	std::memcpy(pTextShadow, &sTextShadow, sizeof(TextShadow));
	pTextShadow->bNotNull = true;
}

TextShadow __stdcall CTextElement::GetTextShadow(int iIndex)
{
	TextShadow sTextShadow = { 0 };
	if (iIndex >= 0 && iIndex < m_TextInfoVec.size())
	{
		TextShadow* pTextShadow = (iIndex < 0) ? &m_sTextShadow : &(m_TextInfoVec[iIndex].sTextShadow);
		std::memcpy(&sTextShadow, pTextShadow, sizeof(pTextShadow));
	}
	return sTextShadow;
}

#if 0
#include "DTypeFontEngine.h"
ITextImage* __stdcall CTextElement::TextImage()
{
	m_pTextLayout->Flush();

	TTSize sTextImageSize = m_pTextLayout->GetTextAreaSize();
	m_pTextImage->Alloc(sTextImageSize.iWidth, sTextImageSize.iHeight, 32);

	DT_DTENGINE hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	DT_MDC	sMdc;
	sMdc.w = m_pTextImage->GetWidth();
	sMdc.h = -m_pTextImage->GetHeight();
	sMdc.l = m_pTextImage->GetBitCount();
	sMdc.m = (DT_UBYTE*)m_pTextImage->GetBits();
	dtOutputSetAsMDC(hEngine, DV_FORMAT_32, 3, &sMdc, 0, 0, m_pTextImage->GetWidth(), m_pTextImage->GetHeight());

	const TCharLayoutInfoVec* pLayoutInfo = m_pTextLayout->LockLayoutInfo();
	for (int i = 0; i < pLayoutInfo->size(); i++)
	{
		TCharLayoutInfo sCharLayoutInfo = pLayoutInfo->at(i);
		CHECK_CONTINUE(sCharLayoutInfo.iCharIndex == 0);

		DT_STYLE_ATTRIBS sStyleAttribs = { { 0, 0 }, { 255, 0, 0, 0 }, 0, NULL };
		DT_STYLE_EFFECTS sStyleEffects = { 0, { DV_EFFECT_NONE, 0, 0 }, { 0, 255, 0, 0 }, NULL };
		DT_TYPE_ATTRIBS  sTypeAttribs  = { 0 };
		sTypeAttribs.font_index = sCharLayoutInfo.iFontIndex;
		sTypeAttribs.transform.params.size_h = sCharLayoutInfo.sCharSize.iWidth;
		sTypeAttribs.transform.params.size_v = sCharLayoutInfo.sCharSize.iHeight;
		dtOutputSetStyleAttribs(hEngine, &sStyleAttribs, 0);
		dtOutputSetStyleEffects(hEngine, &sStyleEffects, 0);
		dtTypesetterSetTypeAttribs(hEngine, &sTypeAttribs, 0);
		dtGlyphDoOutput(hEngine, sCharLayoutInfo.iCharIndex, sCharLayoutInfo.sOrigin.iX, sCharLayoutInfo.sOrigin.iY, 0, nullptr);
	}
	m_pTextLayout->UnLockLayoutInfo();

	return static_cast<ITextImage*>(m_pTextImage);
}
#else
#include "DTypeTextRender.h"
ITextImage* __stdcall CTextElement::TextImage()
{
	m_pTextLayout->Flush();

	TTSize sTextImageSize = m_pTextLayout->GetTextAreaSize();
	m_pTextImage->Alloc(sTextImageSize.iWidth, sTextImageSize.iHeight, 32);

	TextFont sTextFont = { 0 };
	sTextFont.bNotNull = true;
	sTextFont.iColor   = m_iColor;
	sTextFont.bBold    = m_bBold;
	sTextFont.bItalic  = m_bItalic;
	//sTextFont.iBgColor = 0xff1bcdef;

	const TCharLayoutInfoVec* pLayoutInfo = m_pTextLayout->LockLayoutInfo();
	// char backgrounp render
	for (int i = 0; i < pLayoutInfo->size(); i++)
	{
		TCharLayoutInfo sCharLayoutInfo = pLayoutInfo->at(i);

		const TextFont   sSetTextFont   = GetTextFont(i).bNotNull ? GetTextFont(i) : sTextFont;
		const TextBorder sSetTextBorder = GetTextBorder(i).bNotNull ? GetTextBorder(i) : m_sTextBorder;
		const TextShadow sSetTextShadow = GetTextShadow(i).bNotNull ? GetTextShadow(i) : m_sTextShadow;
		CDTypeTextRender::DrawCharBackgrounp(m_pTextImage, sCharLayoutInfo, sSetTextFont);
	}
	// char face border shadow render
	for (int i = 0; i < pLayoutInfo->size(); i++)
	{
		TCharLayoutInfo sCharLayoutInfo = pLayoutInfo->at(i);

		const TextFont   sSetTextFont   = GetTextFont(i).bNotNull   ? GetTextFont(i)   : sTextFont;
		const TextBorder sSetTextBorder = GetTextBorder(i).bNotNull ? GetTextBorder(i) : m_sTextBorder;
		const TextShadow sSetTextShadow = GetTextShadow(i).bNotNull ? GetTextShadow(i) : m_sTextShadow;
		CDTypeTextRender::DrawCharShadow(m_pTextImage, sCharLayoutInfo, sSetTextFont, sSetTextShadow);
		CDTypeTextRender::DrawCharBorder(m_pTextImage, sCharLayoutInfo, sSetTextFont, sSetTextBorder);
		CDTypeTextRender::DrawCharFace(m_pTextImage, sCharLayoutInfo, sSetTextFont);
	}
	m_pTextLayout->UnLockLayoutInfo();

	return static_cast<ITextImage*>(m_pTextImage);
}
#endif

ITextLayout* __stdcall CTextElement::TextLayout()
{
	return static_cast<ITextLayout*>(m_pTextLayout);
}

const double __stdcall CTextElement::GetFontSizeScale()
{
	return m_dScale;
}

const TextInfo __stdcall CTextElement::GetTextInfo(int iIndex)
{
	TextInfo sTextInfo = { 0 };
	if (iIndex < m_TextInfoVec.size())
	{
		std::memcpy(&sTextInfo, &m_TextInfoVec[iIndex], sizeof(TextInfo));
	}
	return sTextInfo;
}