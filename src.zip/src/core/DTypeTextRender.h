#pragma once

#ifndef _DTYPE_TEXT_RENDER_H_
#define _DTYPE_TEXT_RENDER_H_

#include "TextDataDefine.h"
#include "TextDataDefine_imp.h"
using namespace TextEngine;

class CTextImage;

// 
class CDTypeTextRender
{
public:
	static int DrawCharFace(CTextImage*,   const TCharLayoutInfo& , const TextFont&);
	static int DrawCharBorder(CTextImage*, const TCharLayoutInfo& , const TextFont&, const TextBorder&);
	static int DrawCharShadow(CTextImage*, const TCharLayoutInfo& , const TextFont&, const TextShadow&);
	static int DrawCharBackgrounp(CTextImage*, const TCharLayoutInfo&, const TextFont&);

protected:
	CDTypeTextRender(){};
	~CDTypeTextRender(){};
};

#endif // _DTYPE_TEXT_RENDER_H_