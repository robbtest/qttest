#pragma once

#ifndef _TEXT_DATA_DEFINE_H_
#define _TEXT_DATA_DEFINE_H_

#include <cstdint>
#include <vector>

// Text point struct data
struct TTPoint
{
	int iX;
	int iY;
};
using TPoint = struct TTPoint;

// Text size struct data
struct TTSize
{
	uint32_t iWidth;
	uint32_t iHeight;
};
using TSize = struct TTSize;

// Text font geometry layout parameter
struct TTFontLayoutParam
{
	int    iAdvanceHeight;      // common char advance height
	double dUnitRatio;
	int    iFontAscent;
	int    iFontDecline;
	TSize  sCharSize;
};
using TFontLayoutParam = struct TTFontLayoutParam;

// Text layout row parameter
struct TTRowLayoutParam
{
	int    iRowNum;
	int    iMaxFontAscent;      // max font ascent
	int    iMaxFontDecline;     // max font decline
	int    iWidth;              // width of row
	double dAngle;              // angle of row
};
using TRowLayoutParam = struct TTRowLayoutParam;
using TRowLayoutParamVec = std::vector<TRowLayoutParam>;

// Text char layout infomation
struct TTCharLayoutInfo
{
	int      iFontIndex;
	int      iCharIndex;
	TPoint   sOrigin;
	TSize    sAdvance;
	TSize    sCharSize;
	int      iMaxAscent;
	int      iMaxDecent;
	int      iAscent;
};
using TCharLayoutInfo    = struct TTCharLayoutInfo;
using TCharLayoutInfoVec = std::vector<TCharLayoutInfo>;

// Text char effect infomation
/*
struct TTCharEffectInfo
{
	int      iColor;
	int      iBoldSize;
};
using TCharEffectInfo = struct TTCharEffectInfo;
using TCharEffectInfoVec = std::vector<TCharEffectInfo>;
*/

#endif // _TEXT_DATA_DEFINE_H_