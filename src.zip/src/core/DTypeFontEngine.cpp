#include "DTypeFontEngine.h"
#include "MacroDefine.h"
#include "PathUtil.h"
#include "FileUtil.h"
#include "GetResource.h"

#include <cassert>
#include <cstring>
#include <iostream>
using namespace std;

// 
const char dtype_inf_file[]       = "dtype.inf"; 
const char font_file_suffix_ttf[] = ".ttf"; 
const char font_file_suffix_ttc[] = ".ttc"; 
const char font_file_suffix_otf[] = ".otf"; 




CDTypeFontEngine* CDTypeFontEngine::m_pFontEngine = nullptr;

CDTypeFontEngine* CDTypeFontEngine::Instance()
{
	if (m_pFontEngine == nullptr)
	{
		m_pFontEngine = new CDTypeFontEngine;
	}
	return m_pFontEngine;
}

void CDTypeFontEngine::Uninstance()
{
	SAFE_DELETE(m_pFontEngine);
}

int CDTypeFontEngine::Init()
{
	InitDType();
	InitDefaultFont();

	bool bAutoLoadSysFont = true;
	char szPath[1024] = "";
	if (bAutoLoadSysFont)
	{
		CPathUtil::GetExecutePath(szPath, 1024);
		std::strcat(szPath, "font/");
		InitFont(szPath);
		std::memset(szPath, 0, 1024);
	}

#ifdef WIN32
	char* pWindir = std::getenv("windir");
	std::memcpy(szPath, pWindir,1024);
	std::strcat(szPath, "\\Fonts\\");
#elif defined(LINUX)
	std::memcpy(szPath, "/usr/share/fonts/",1024);
#elif defined(MACOS)
	std::memcpy(szPath, "/system/library/fonts/",1024);
#else
    assert(false);
#endif

	if (bAutoLoadSysFont)
	{
		InitFont(szPath);
	}

    return 0;
}

int CDTypeFontEngine::LoadFonts(const char* szFontFold)
{
/*	std::mbstate_t state = std::mbstate_t();
	wchar_t wszFontFold[512] = { 0 };
	mbsrtowcs(wszFontFold, &szFontFold, 512, &state);
	m_pFontLibrary->AddFonts(wszFontFold);*/

	return 0;
}

int CDTypeFontEngine::GetFontCount()
{
    int iCount = static_cast<int>(m_fontMap.size());
	return iCount;
}

int CDTypeFontEngine::GetFontName(int iIndex, char* pFontName)
{
    FONT_INFO& sFontInfo = m_fontInfoMap[m_fontVec[iIndex]];
    std::memcpy(pFontName, sFontInfo.szFontName.c_str(), sFontInfo.szFontName.size());
    pFontName[sFontInfo.szFontName.size()] = '\0';
	return 0;
}

int CDTypeFontEngine::GetFontIndex(const char* pFontName)
{
	CHECK_RETURN_RET(pFontName == nullptr, -1);
	string szFontName = pFontName;
	int iRet = -1;
	if (m_fontMap.count(szFontName))
	{
		iRet = m_fontMap[szFontName];
	}
	else
	{
		iRet = DEFALUT_FONT_INDEX;
	}
	return iRet;
}

CDTypeFontEngine::CDTypeFontEngine()
{
	
}


CDTypeFontEngine::~CDTypeFontEngine()
{
	
}

int CDTypeFontEngine::InitDType()
{
	int iRet = 0;

    do
    {
        // Get dtype.inf file path
	    char szPath[512] = "";
	    iRet = CPathUtil::GetExecutePath(szPath, 512);
		if(IS_FAILED(iRet))
		{
			cout << "Error: Get execute path failed with code ." << iRet << endl;
		}
	    CHECK_BREAK(iRet != 0);
        std::strcat(szPath, "dtype.inf");

        // Create and initialize D-Type Standard Engine - via stream
		DT_STREAM_DESC sd_ini;
		if (CFileUtil::IsFileExist(szPath))
		{
			DT_STREAM_FILE(sd, szPath);
			std::memcpy(&sd_ini, &sd, sizeof(sd));
		}
		else
		{
			const unsigned char* pMem = get_file_dtype_inf();
			const unsigned int   iMem = get_file_dtype_inf_size();
			DT_STREAM_MEMORY(sd, pMem, iMem);
			std::memcpy(&sd_ini, &sd, sizeof(sd));
		}
        int iDTRet = dtEngineIniViaStream(&m_hEngine, &sd_ini, nullptr);
        if(iDTRet == 0 || m_hEngine == nullptr)
        {
			cout << "Error: dtEngineIniViaStream call failed ." << endl;
        }
        CHECK_BREAK(iDTRet == 0 && (iRet = 3) != 0);

        //
        iDTRet = dtRasterizerRealloc(m_hEngine, 1200, 1000, 8, 1);
		if (iDTRet == 0)
		{
			cout << "dtRasterizerRealloc call Failed" << endl;
		}
		CHECK_BREAK(iDTRet == 0 && (iRet = 4) != 0);
		// 
		iDTRet = dtTypesetterSetSizeSubscale(m_hEngine, 1, 1, 0);
		if (iDTRet == 0)
		{
			cout << "dtTypesetterSetSizeSubscale call Failed" << endl;
		}
		CHECK_BREAK(iDTRet == 0 && (iRet = 5) != 0);
    }while(false);

	return iRet;
}
#include <fstream>
int CDTypeFontEngine::InitDefaultFont()
{
	int iRet = 0;

	do
	{
		const unsigned char* pMem = get_file_arialuni_ttf();
		const unsigned int   iMem = get_file_arialuni_ttf_size();
		//std::ofstream s;
		//s.open("arialuni1.ttf", ios::binary);
		//s.write((const char*)pMem, iMem);
		//s.close();
		CHECK_BREAK((pMem == nullptr || iMem == 0) && (iRet = 1) != 0);
		DT_STREAM_MEMORY(sd_font, pMem, iMem);
		DT_SWORD iFontIndex = dtFontAddViaStream(m_hEngine, DV_FONT_OPENTYPE_TTF_WINUNICODE, NULL, 0, -1, 0, 1, &sd_font);
		if (iFontIndex < 0)
		{
			cout << "dtFontAddViaStream - Failed" << endl;
		}
		CHECK_BREAK(iFontIndex < 0 && (iRet = 4) != 0);
		FONT_INFO sFontInfo;
		sFontInfo.iIndex = iFontIndex;
		sFontInfo.szFileName = "arialuni_ttf";
		int iRetTmp = ParseFontInfo(sFontInfo);
		if (iRetTmp != 0)
		{
			cout << "ParseFontInfo - Failed:[" << iRetTmp << "]" << endl;
		}
		CHECK_BREAK(iRetTmp != 0 && (iRet = 5) != 0);
	} while (false);

	return iRet;
}

#ifdef WIN32
#include <Windows.h>
void CDTypeFontEngine::InitFont(const char* szFontDir)
{
	CHECK_RETURN(!szFontDir);

	char szWildcardFontFile[MAX_PATH] = { 0 };
	memcpy(szWildcardFontFile, szFontDir, strlen(szFontDir));
	strcat(szWildcardFontFile, "*.*");
	HANDLE hFind = INVALID_HANDLE_VALUE;

	do 
	{
		WIN32_FIND_DATAA FindFileData;
		hFind = FindFirstFileA(szWildcardFontFile, &FindFileData);
		CHECK_BREAK(hFind == INVALID_HANDLE_VALUE);
		do 
		{
			string szFontFilePath;
			szFontFilePath += szFontDir;
			szFontFilePath += FindFileData.cFileName;
			const char* pDot = strrchr(szFontFilePath.c_str(), '.');
			CHECK_CONTINUE(!pDot);
			const char* suffixArr[] = { font_file_suffix_ttf ,font_file_suffix_ttc ,font_file_suffix_otf };
			int  iCount = sizeof(suffixArr) / sizeof(suffixArr[0]);
			bool bSupport = false;
			for (int i = 0; i < iCount; i++)
			{
				if (strcmp(pDot, suffixArr[i]) == 0)
				{
					bSupport = true;
					break;
				}
			}
			CHECK_CONTINUE(!bSupport);
			FONT_INFO sFontInfo;
			sFontInfo.szFileDir  = szFontDir;
			sFontInfo.szFileName = FindFileData.cFileName;
			AppendFont(sFontInfo);
		} while (FindNextFileA(hFind, &FindFileData) && INVALID_HANDLE_VALUE != hFind);
	} while (false);

	if (hFind != INVALID_HANDLE_VALUE)
	{
		FindClose(hFind);
	}
}
#elif defined(LINUX) || defined(MACOS)
#include <dirent.h>
#include <sys/stat.h>
void CDTypeFontEngine::InitFont(const char* szFontDir)
{
	CHECK_RETURN(!szFontDir);

    struct dirent** ppNamelist = nullptr;

	do
	{
        int iCount = scandir(szFontDir, &ppNamelist, 0, alphasort);
        for(int i = 0; i< iCount; i++)
        {
        	string szFontFilePath;
        	szFontFilePath = ppNamelist[i]->d_name;
        	CHECK_CONTINUE(szFontFilePath == "." || szFontFilePath == "..");
        	szFontFilePath  = szFontDir;
        	szFontFilePath += ppNamelist[i]->d_name;
        	// Is directory
        	struct stat sStatTmp;
        	stat(szFontFilePath.c_str(), &sStatTmp);
        	if(S_ISDIR(sStatTmp.st_mode))
        	{
        		szFontFilePath += "/";
        		InitFont(szFontFilePath.c_str());
        	}
        	CHECK_CONTINUE(S_ISDIR(sStatTmp.st_mode));
        	// 
        	const char* pDot = strrchr(szFontFilePath.c_str(), '.');
			CHECK_CONTINUE(!pDot);
			const char* suffixArr[] = { font_file_suffix_ttf ,font_file_suffix_ttc ,font_file_suffix_otf };
			int  iSuffixCount = sizeof(suffixArr) / sizeof(suffixArr[0]);
			bool bSupport = false;
			for (int i = 0; i < iSuffixCount; i++)
			{
				if (strcmp(pDot, suffixArr[i]) == 0)
				{
					bSupport = true;
					break;
				}
			}
			CHECK_CONTINUE(!bSupport);
			FONT_INFO sFontInfo;
			sFontInfo.szFileDir  = szFontDir;
			sFontInfo.szFileName = ppNamelist[i]->d_name;;
			AppendFont(sFontInfo);
        }
	}while(false);

    SAFE_FREE(ppNamelist);
}
#else
    assert(false);
#endif

int  CDTypeFontEngine::AppendFont(FONT_INFO& sFontInfo)
{
	CHECK_RETURN_RET(!m_hEngine, 1);

	string szFontPath = sFontInfo.szFileDir + sFontInfo.szFileName;
	int iRet = 0;

	do 
	{
		const char* pDot = std::strrchr(szFontPath.c_str(), '.');
		if (pDot == nullptr)
		{
			cout << "strrchr - Failed" << endl;
		}
		CHECK_BREAK(pDot == nullptr && (iRet = 2) != 0);
		int iFormatIdIndex = -1; 
		DT_ID_SWORD fontFormatIdArr[] = { DV_FONT_OPENTYPE_TTF_WINUNICODE, DV_FONT_OPENTYPE_CFF_WINUNICODE }; 
		const char* suffixArr[] = { font_file_suffix_ttf, font_file_suffix_ttc, font_file_suffix_otf }; 
		int iCountFormat = sizeof(fontFormatIdArr) / sizeof(fontFormatIdArr[0]); 
		int iCountSuffix = sizeof(suffixArr) / sizeof(suffixArr[0]);
		for (int i = 0; i < iCountSuffix; i++)
		{
			if (strcmp(pDot, suffixArr[i]) == 0)
			{
				iFormatIdIndex = 0;
				break;
			}
		}
		CHECK_BREAK(iFormatIdIndex < 0 && (iRet = 3) != 0);
	_AddLabel:
		int ifontFormatId = fontFormatIdArr[iFormatIdIndex];
		DT_STREAM_FILE(sd_font, szFontPath.c_str());
		DT_SWORD iFontIndex = dtFontAddViaStream(m_hEngine, ifontFormatId, NULL, 0, -1, 0, 1, &sd_font);
		if (iFontIndex < 0)
		{
			cout << "dtFontAddViaStream - Failed" << endl;
		}
		CHECK_BREAK(iFontIndex < 0 && (iRet = 4) != 0);
		int iRetTmp = dtFontMakeActive(m_hEngine, iFontIndex, 1, nullptr);
		if (iRetTmp == 0)
		{
			assert(dtFontRemove(m_hEngine, iFontIndex) == 1);
			if (iFormatIdIndex < (iCountFormat - 1))
			{
				iFormatIdIndex++;
				goto _AddLabel;
			}
		}
		CHECK_BREAK(iRetTmp == 0 && (iRet = 4) != 0);
		sFontInfo.iIndex = iFontIndex;
		iRetTmp = ParseFontInfo(sFontInfo);
		if (iRetTmp != 0)
		{
			cout << "ParseFontInfo - Failed:[" << iRetTmp <<"]"<< endl;
		}
		CHECK_BREAK(iRetTmp != 0 && (iRet = 5) != 0);
	} while (false);

	return iRet;
}

void CDTypeFontEngine::RemoveFont()
{
	//dtFontRemove(m_hEngine, nFontIndex);
}

int CDTypeFontEngine::ParseFontInfo(FONT_INFO& sFontInfo)
{
	CHECK_RETURN_RET(!m_hEngine, 1);
	CHECK_RETURN_RET(sFontInfo.iIndex < 0, 1);
	CHECK_RETURN_RET(m_fontInfoMap.count(sFontInfo.iIndex) > 0, 2);

	int iFontIndex = sFontInfo.iIndex;
	DT_UBYTE  uBuf[256];
	memset(uBuf, 0, sizeof(uBuf));
	int iGetInfo = 0;

	//wchar_t	uName[256] = { '\0' };
	//iGetInfo = dtFontGetStringValue(m_hEngine, iFontIndex, DV_SVAL_UNI_FONTNAME, uBuf, 256);
	//int idx = 0;
	//unsigned short *wbuf = (unsigned short*)uBuf;
	//while (*wbuf)
	//{
	//	unsigned short tmp = *wbuf;
	//	unsigned short tmp2 = tmp >> 8 | tmp << 8;
	//	uName[idx] = tmp2;
	//	wbuf++;
	//	idx++;
	//}
	//wstring wszFontName = uName;
	iGetInfo = dtFontGetStringValue(m_hEngine, iFontIndex, DV_SVAL_ASC_FONTNAME, uBuf, 256);
	sFontInfo.szFontName = (char*)uBuf;
	iGetInfo = dtFontGetStringValue(m_hEngine, iFontIndex, DV_SVAL_ASC_FAMILYNAME, uBuf, 256);
	sFontInfo.szFamilyName = (char*)uBuf;
	iGetInfo = dtFontGetStringValue(m_hEngine, iFontIndex, DV_SVAL_ASC_SUBFAMILYNAME, uBuf, 256);
	sFontInfo.szSubfamilyName = (char*)uBuf;

    string szSubfamilyName = sFontInfo.szSubfamilyName;
    bool bBold   = szSubfamilyName.find("Bold") != std::string::npos;
    bool bItalic = szSubfamilyName.find("Italic") != std::string::npos;
	if (!sFontInfo.szFontName.empty() && !m_fontMap.count(sFontInfo.szFontName) && !bBold && !bItalic)
	{
		m_fontMap[sFontInfo.szFontName] = iFontIndex;
        m_fontInfoMap[iFontIndex] = sFontInfo;
        m_fontVec.push_back(iFontIndex);
	}
	else
	{
		m_fontUnknowMap[sFontInfo.szFileName] = iFontIndex;
	}

	return 0;
}