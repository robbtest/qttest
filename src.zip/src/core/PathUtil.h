#pragma once

#include <string>

// 
class CPathUtil
{
public:
	static int GetExecutePath(char* pPathBuf, int uBufSize);

protected:
	CPathUtil();
	~CPathUtil();
};
