#include "PathUtil.h"
#include <cassert>
#include <cstring>

#ifdef WIN32
    #include <windows.h>
#elif  defined(LINUX) || defined(MACOS)
    #include <unistd.h>
#else

#endif


int CPathUtil::GetExecutePath(char* pPathBuf, int uBufSize)
{
	assert(pPathBuf != nullptr && uBufSize > 0);

	int  iRet = 0;
	char pathbuf[512] = { 0 };
#ifdef WIN32
    int iRetTmp = GetModuleFileNameA(nullptr, pathbuf, sizeof(pathbuf) - 1);
	assert(iRetTmp !=0 );
	for (size_t i = strlen(pathbuf); i > 0; --i)
	{
		if ('\\' == pathbuf[i] || '/' == pathbuf[i])
		{
			pathbuf[i + 1] = 0;
			break;
		}
	}
#elif  defined(LINUX)
    int iRetTmp = readlink("/proc/self/exe", pathbuf, 512);
    assert(iRetTmp != -1);
    char* pSlash = std::strrchr(pathbuf, '/');
    *(pSlash+1) = 0;
#elif  defined(MACOS)
	getcwd(pathbuf, 1024);
	std::strcat(pathbuf, "/");
#else
	assert(false);
#endif

	std::memcpy(pPathBuf, pathbuf, strlen(pathbuf));

	return iRet;
}

CPathUtil::CPathUtil()
{

}
