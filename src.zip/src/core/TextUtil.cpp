#include "TextUtil.h"
#include "DTypeFontEngine.h"
#include "TextImage.h"
#include "TextElement.h"


IFontEngine* TextUtil::GetFontEngine()
{
	CDTypeFontEngine* pDTypeFontEngine = CDTypeFontEngine::Instance();
	return static_cast<IFontEngine*>(pDTypeFontEngine);
}

int TextUtil::CreateTextImage(ITextImage** ppTextImage)
{
	if (ppTextImage == nullptr) return 1;

	(*ppTextImage) = static_cast<ITextImage*>(new CTextImage());
	int iRet = (*ppTextImage) != nullptr ? 0 : 2;

	return iRet;
}

int TextUtil::CreateTextElement(ITextElement** ppTextElement)
{
	if (ppTextElement == nullptr) return 1;

	(*ppTextElement) = static_cast<ITextElement*>(new CTextElement());
	int iRet = (*ppTextElement) != nullptr ? 0 : 2;

	return iRet;
}