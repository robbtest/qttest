#include <iostream>
using namespace std;
#include <cassert>
#include <cstring>

#include "MacroDefine.h"
#include "StringUtil.h"

#include "TextHLayout.h"
#include "TextElement.h"
#include "DTypeFontEngine.h"

CDTypeTextHLayout::CDTypeTextHLayout()
{
	std::memset(&m_sTextAreaSize, 0, sizeof(m_sTextAreaSize));
}

CDTypeTextHLayout::~CDTypeTextHLayout()
{

}

void __stdcall CDTypeTextHLayout::Release()
{
	delete this;
}

void __stdcall CDTypeTextHLayout::SetHCharSpace(int iSpace)
{
	std::lock_guard<std::mutex> autolock(m_LayoutMutex);
	m_iHCharSpace = iSpace;
}

void __stdcall CDTypeTextHLayout::SetVCharSpace(int iSpace)
{
	std::lock_guard<std::mutex> autolock(m_LayoutMutex);
	m_iVCharSpace = iSpace;
}

int CDTypeTextHLayout::Init(CTextElement* pTextElement)
{
	CHECK_RETURN_RET(pTextElement == nullptr, 1);

	m_hEngine = CDTypeFontEngine::Instance()->GetFontEngine();
	assert(m_hEngine);
	m_pTextElement = pTextElement;

	int iRet = 0;

	return iRet;
}

void CDTypeTextHLayout::Flush()
{
	PreFlushLayout();
	FlushLayout();
}

const TTSize CDTypeTextHLayout::GetTextAreaSize()
{
	return m_sTextAreaSize;
}

const TCharLayoutInfoVec* CDTypeTextHLayout::LockLayoutInfo()
{
	m_CharLayoutInfoVecMutex.lock();
	return &m_CharLayoutInfoVec;
}

void CDTypeTextHLayout::UnLockLayoutInfo()
{
	m_CharLayoutInfoVecMutex.unlock();
}

TFontLayoutParam CDTypeTextHLayout::GetFontLayoutParam(int iFontIndex, int iFontSize)
{
	CDTypeFontEngine* pFontEngine = CDTypeFontEngine::Instance();
	assert(pFontEngine != nullptr);
	TFontLayoutParam sFontLayoutParam = { 0 };

	do
	{
		//
		CHECK_BREAK(iFontIndex < 0);
		CHECK_BREAK(iFontSize  <= 0);
		DT_UWORD      uwdFontXbs = 0;
		DT_UWORD      uwdFontYbs = 0;
		DT_RECT_SWORD swdExtent  = { 0 };
		int iDTRet = dtFontGetMetrics(m_hEngine, iFontIndex, &uwdFontXbs, &uwdFontYbs, &swdExtent);
		if (iDTRet == 0)
		{
			cout << "Call dtFontGetMetrics Failed ." << endl;
		}
		CHECK_BREAK(iDTRet == 0);
		sFontLayoutParam.iAdvanceHeight    = swdExtent.ymx - swdExtent.ymn;
		sFontLayoutParam.dUnitRatio        = static_cast<double>(iFontSize) / (swdExtent.ymx - swdExtent.ymn);
		sFontLayoutParam.iFontAscent       = static_cast<int>(sFontLayoutParam.dUnitRatio * swdExtent.ymx + 0.5);
		sFontLayoutParam.iFontDecline      = iFontSize - sFontLayoutParam.iFontAscent; // static_cast<int>(sFontLayoutParam.dUnitRatio * swdExtent.ymn + 0.5);
		sFontLayoutParam.sCharSize.iWidth  = static_cast<int>(sFontLayoutParam.dUnitRatio * uwdFontXbs + 0.5);
		sFontLayoutParam.sCharSize.iHeight = static_cast<int>(sFontLayoutParam.dUnitRatio * uwdFontYbs + 0.5);
	} while (false);

	return sFontLayoutParam;
}

void CDTypeTextHLayout::PreFlushLayout()
{
	CDTypeFontEngine* pFontEngine = CDTypeFontEngine::Instance();
	assert(pFontEngine != nullptr);
	int     iFontIndex = pFontEngine->GetFontIndex(m_pTextElement->GetFontFamily());
	double  dFontSizeScale = m_pTextElement->GetFontSizeScale();
	double  dFontSize  = m_pTextElement->GetFontSize() * dFontSizeScale;
	string  szText     = m_pTextElement->GetText();
	wstring wszText    = CStringUtil::CharToWChar(szText.c_str());

	// external layout parameter
	m_LayoutMutex.lock();
	int iHCharSpace = m_iHCharSpace;
	int iVCharSpace = m_iVCharSpace;
	m_LayoutMutex.unlock();
	bool bChangeLine = false;
	TRowLayoutParam sTRowLayoutParam = { 0 };
	m_RowLayoutParamVec.clear();

	for (int i = 0; i < wszText.size(); i++)
	{
		DT_ID_ULONG   uCharIdx = 0;
		DT_SWORD      swdRet = 0;
		DT_RECT_SWORD swdExtent = { 0 };
		DT_ADVANCE    sAdvance = { 0 };

		wchar_t wchar = wszText.at(i);
		// get global font index and font size value for text
		int     iFontIdx = iFontIndex;
		int     iFontSz = static_cast<int>(dFontSize);
		// get special settings for char
		const TextFont sTextFont = m_pTextElement->GetTextFont(i);
		if (sTextFont.bNotNull)
		{
			iFontIdx = sTextFont.iFontIndex;
			iFontSz  = sTextFont.iFontSize*dFontSizeScale;
		}
		// confirm font index and get geometry parameter of char
		uCharIdx = dtFontGetGlyphIndex(m_hEngine, iFontIdx, wchar);
		iFontIdx = uCharIdx != 0 ? iFontIdx : 0;
		uCharIdx = dtFontGetGlyphIndex(m_hEngine, iFontIdx, wchar);
		swdRet = dtGlyphGetMetricsPlus(m_hEngine, iFontIdx, uCharIdx, &sAdvance, &swdExtent, 0);
		CHECK_CONTINUE(swdRet == 0);
		// set TRowLayoutParam
		TFontLayoutParam sFontLayoutParam = GetFontLayoutParam(iFontIdx, iFontSz);
		if (sTRowLayoutParam.iMaxFontAscent < sFontLayoutParam.iFontAscent)
		{
			sTRowLayoutParam.iMaxFontAscent = sFontLayoutParam.iFontAscent;
		}
		if (sTRowLayoutParam.iMaxFontDecline < sFontLayoutParam.iFontDecline)
		{
			sTRowLayoutParam.iMaxFontDecline = sFontLayoutParam.iFontDecline;
		}
		//sTRowLayoutParam.iWidth += static_cast<int>(sFontLayoutParam.dUnitRatio * sAdvance.w);
		// put TRowLayoutParam into container
		bChangeLine = (wchar == L'\r' || wchar == L'\n');
		if (!bChangeLine)
		{
			sTRowLayoutParam.iWidth += iHCharSpace;
		}
		else
		{
			sTRowLayoutParam.iWidth += static_cast<int>(sFontLayoutParam.dUnitRatio * sAdvance.w);
		}
		if (bChangeLine || (!bChangeLine && i == wszText.size() - 1))
		{
			int iRowNum = sTRowLayoutParam.iRowNum;
			m_RowLayoutParamVec.push_back(sTRowLayoutParam);
			std::memset(&sTRowLayoutParam, 0, sizeof(sTRowLayoutParam));
			sTRowLayoutParam.iRowNum = ++iRowNum;
		}
	}
}

void CDTypeTextHLayout::FlushLayout()
{
	CDTypeFontEngine* pFontEngine = CDTypeFontEngine::Instance();
	assert(pFontEngine != nullptr);
	int    iFontIndex = pFontEngine->GetFontIndex(m_pTextElement->GetFontFamily());
	double dFontSizeScale = m_pTextElement->GetFontSizeScale();
	double dFontSize = m_pTextElement->GetFontSize()*dFontSizeScale;

	string szText     = m_pTextElement->GetText();
	wstring wszText = CStringUtil::CharToWChar(szText.c_str());

	bool bChangeLine = false;
	int  iRowNum = 0;
	int  iLastRowMaxHeight = 0;
	TCharLayoutInfo sLastCharLayoutInfo = { 0 };

	// external layout parameter
	m_LayoutMutex.lock();
	int iHCharSpace = m_iHCharSpace;
	int iVCharSpace = m_iVCharSpace;
	m_LayoutMutex.unlock();
	// layout info for render
	std::lock_guard<std::mutex> autolock(m_CharLayoutInfoVecMutex);
	m_CharLayoutInfoVec.clear();

	for (int i = 0; i < wszText.size(); i++)
	{
		DT_ID_ULONG   uCharIdx  = 0;
		DT_SWORD      swdRet    = 0;
		DT_RECT_SWORD swdExtent = { 0 };
		DT_ADVANCE    sAdvance  = { 0 };

		// get row layout param
		TRowLayoutParam sRowLayoutParam = m_RowLayoutParamVec.at(iRowNum);
		// get global font index and font size value for text
		int iFontIdx = iFontIndex;
		int iFontSz  = static_cast<int>(dFontSize);
		// special settings for char
		const TextFont sTextFont = m_pTextElement->GetTextFont(i);
		if (sTextFont.bNotNull)
		{
			iFontIdx = sTextFont.iFontIndex;
			iFontSz  = sTextFont.iFontSize*dFontSizeScale;
		}
		// confirm font index
		wchar_t wchar = wszText.at(i);
		uCharIdx = dtFontGetGlyphIndex(m_hEngine, iFontIdx, wchar);
		iFontIdx = uCharIdx != 0 ? iFontIdx : 0;
		uCharIdx = dtFontGetGlyphIndex(m_hEngine, iFontIdx, wchar);
		swdRet   = dtGlyphGetMetricsPlus(m_hEngine, iFontIdx, uCharIdx, &sAdvance, &swdExtent, 0);
		CHECK_CONTINUE(swdRet == 0);
		// Get char geometry parameter
		TFontLayoutParam sFontLayoutParam = GetFontLayoutParam(iFontIdx, iFontSz);
		CHECK_CONTINUE(sFontLayoutParam.iAdvanceHeight == 0);
		sAdvance.h = sFontLayoutParam.iAdvanceHeight;
		int iOriginYBaseLine = sLastCharLayoutInfo.sOrigin.iY - sLastCharLayoutInfo.iMaxAscent;
		// Set char parameter of layout
		if (bChangeLine)
		{
			iLastRowMaxHeight = m_RowLayoutParamVec.at(iRowNum - 1).iMaxFontAscent + m_RowLayoutParamVec.at(iRowNum - 1).iMaxFontDecline;
		}
		TTCharLayoutInfo sCharLayoutInfo;
		sCharLayoutInfo.iFontIndex       = iFontIdx;
		sCharLayoutInfo.iCharIndex       = uCharIdx;
		sCharLayoutInfo.iMaxAscent       = sRowLayoutParam.iMaxFontAscent;
		sCharLayoutInfo.iMaxDecent       = sRowLayoutParam.iMaxFontDecline;
		sCharLayoutInfo.iAscent          = sFontLayoutParam.iFontAscent;
		sCharLayoutInfo.sOrigin.iX       = bChangeLine ? 0 : sLastCharLayoutInfo.sOrigin.iX + sLastCharLayoutInfo.sAdvance.iWidth + (i != 0 ? iHCharSpace : 0);
		sCharLayoutInfo.sOrigin.iY       = iOriginYBaseLine + sCharLayoutInfo.iMaxAscent + (bChangeLine ? iLastRowMaxHeight + iVCharSpace : 0);
		sCharLayoutInfo.sAdvance.iWidth  = static_cast<uint32_t>(sFontLayoutParam.dUnitRatio * sAdvance.w);
		sCharLayoutInfo.sAdvance.iHeight = static_cast<uint32_t>(sFontLayoutParam.dUnitRatio * sAdvance.h);
		sCharLayoutInfo.sCharSize        = sFontLayoutParam.sCharSize;
		m_CharLayoutInfoVec.push_back(sCharLayoutInfo);
		// ready for next char layout parameter
		std::memcpy(&sLastCharLayoutInfo, &sCharLayoutInfo, sizeof(TTCharLayoutInfo));
		bChangeLine = (wchar == L'\r' || wchar == L'\n');
		iRowNum += bChangeLine ? 1 : 0;
		// adaptive image size
		uint32_t iCurLineMaxWidth  = sCharLayoutInfo.sOrigin.iX + sCharLayoutInfo.sAdvance.iWidth;
		uint32_t iCurLineMaxHeight = sCharLayoutInfo.sOrigin.iY + sCharLayoutInfo.sAdvance.iHeight - sFontLayoutParam.iFontAscent;
		m_sTextAreaSize.iWidth  = m_sTextAreaSize.iWidth  > iCurLineMaxWidth  ? m_sTextAreaSize.iWidth  : iCurLineMaxWidth;
		m_sTextAreaSize.iHeight = m_sTextAreaSize.iHeight > iCurLineMaxHeight ? m_sTextAreaSize.iHeight : iCurLineMaxHeight;
	}
}