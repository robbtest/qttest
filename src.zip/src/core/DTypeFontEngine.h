#pragma once

#ifndef _DTYPE_FONT_ENGINE_H_
#define _DTYPE_FONT_ENGINE_H_

#include "core/dtype.h"
#include "IFontEngine.h"
using namespace TextEngine;

#include <string>
using std::string;
#include <map>
#include <vector>

struct TFONT_INFO 
{ 
	int iIndex; 
	string szShowName; 
	string szFileDir; 
	string szFileName; 
	string szFontName; 
	string szFamilyName; 
	string szSubfamilyName; 
}; 
using FONT_INFO = struct TFONT_INFO; 


#define DEFALUT_FONT_INDEX	    0

// DType font engine class
class CDTypeFontEngine : public IFontEngine
{
public:
	static  CDTypeFontEngine*     Instance();
	static  void                  Uninstance();
	// IFontEngine
	virtual int 	    __stdcall Init();
	virtual int         __stdcall LoadFonts(const char* szFontFold);
	virtual int         __stdcall GetFontCount();
	virtual int         __stdcall GetFontName(int iNumber, char* pFontName);
	virtual int         __stdcall GetFontIndex(const char* pFontName);
	//
	virtual DT_DTENGINE           GetFontEngine(){ return m_hEngine; };

protected:
	CDTypeFontEngine();
	virtual ~CDTypeFontEngine();

	int  InitDType();
	int  InitDefaultFont();
	void InitFont(const char* szFontDir);
	int  AppendFont(FONT_INFO& sFontInfo);
	void RemoveFont();

	int  ParseFontInfo(FONT_INFO& sFontInfo);

private:
	static CDTypeFontEngine* 	    m_pFontEngine;
	DT_DTENGINE         			m_hEngine = nullptr;
	std::map<string, int> 			m_fontMap; 
	std::map<int, FONT_INFO> 		m_fontInfoMap; 
	std::map<string, int>  			m_fontUnknowMap; 
	std::vector<int> 			    m_fontVec;
};

#endif // _DTYPE_FONT_ENGINE_H_