#pragma once

#ifndef _DTYPE_TEXT_HLAYOUT_H_
#define _DTYPE_TEXT_HLAYOUT_H_

#include <mutex>

#include "ITextLayout.h"
using namespace TextEngine;

#include "core/dtype.h"
#include "TextDataDefine_imp.h"


class CTextElement;

//
class CDTypeTextHLayout : public ITextLayout
{
public:
	CDTypeTextHLayout();
	virtual ~CDTypeTextHLayout();
	// ITextLayout
	virtual void   __stdcall          Release();
	virtual void   __stdcall          SetHCharSpace(int iSpace);
	virtual void   __stdcall          SetVCharSpace(int iSpace);
	//
	virtual int                       Init(CTextElement* pTextElement);
    virtual void                      Flush();
	// 
	virtual const TTSize              GetTextAreaSize();
	virtual const TCharLayoutInfoVec* LockLayoutInfo();
	virtual void                      UnLockLayoutInfo();

protected:
	TFontLayoutParam GetFontLayoutParam(int iFontIndex, int iFontSize);
	void             PreFlushLayout();
	void             FlushLayout();

private:
	// 
	CTextElement*				    m_pTextElement   = nullptr;    // layout for object
	DT_DTENGINE         		    m_hEngine        = nullptr;    // dtype handle
	// PreLayout info
	TRowLayoutParamVec              m_RowLayoutParamVec;           // row layout parameter
	int                             m_iHCharSpace    = 0;          // horizonal char space
	int                             m_iVCharSpace    = 0;          // vertical char space
	// Layout info
	std::mutex                      m_LayoutMutex;                 // layout mutex
	std::mutex                      m_CharLayoutInfoVecMutex;      // mutex for m_CharLayoutInfoVec
	TCharLayoutInfoVec              m_CharLayoutInfoVec;           // char layout info
	TTSize                          m_sTextAreaSize;               // image area for text
};

#endif // _DTYPE_TEXT_HLAYOUT_H_