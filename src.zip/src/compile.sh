#!/bin/sh

make resource_c
make resource_d
make core_c
make core_d
make sample_c
make sample_d
