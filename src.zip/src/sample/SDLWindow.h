#pragma once

#include "SDL.h"

// 
class SDLWindow
{
public:
	SDLWindow();
	virtual ~SDLWindow();

	int  Init(int iWidth, int iHeiht);
	void Update(const char* pSkBitmap);
	int  EventLoop();

protected:
	void UnInit();
	void OnEvent_Keyup(SDL_Event* pEvent);
	void OnEvent_KeyupQ(SDL_KeyboardEvent* pEvent);
	void OnEvent_KeyupR(SDL_KeyboardEvent* pEvent);
	void OnEvent_KeyupUp(SDL_KeyboardEvent* pEvent);

private:
	SDL_Window*			m_pWin		= nullptr;
	SDL_Renderer*		m_pRenderer = nullptr;
	SDL_Texture*		m_pTexture  = nullptr;
	uint32_t			m_uWidth    = 0;
	uint32_t			m_uHeight   = 0;
};

