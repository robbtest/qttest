#include <iostream>
using namespace std;
#include <cassert>

#include "TextEngineLib.h"
using namespace TextEngine;
#include "SDLWindow.h"

#ifdef WIN32
char* strInputPng = "d:/111.png";
char* strOutputPng = "d:/333.png";
#else
char* strInputPng = "/tmp/111.png";
char* strOutputPng = "/tmp/333.png";
#endif

int main(int argc, char** argv)
{
    IFontEngine* pFontEngine = TextUtil::GetFontEngine();
    pFontEngine->Init();

    char szFamilyName[512] = { 0 };
    for(int i = 0; i < pFontEngine->GetFontCount(); i++)
    {
        pFontEngine->GetFontName(i, szFamilyName);
        cout << i << " - " << szFamilyName << endl;
    }

    ITextImage* pTextImage = nullptr;
    int iRetTmp = TextUtil::CreateTextImage(&pTextImage);
    assert(pTextImage);
	pTextImage->LoadFile(strInputPng);
	//cout << pTextImage->GetWidth() << "x" << pTextImage->GetHeight() << " - "
	//	<< pTextImage->GetPitch() << endl;
    //pTextImage->SaveFile(strOutputPng);


    ITextElement* pTextElement = nullptr;
    iRetTmp = TextUtil::CreateTextElement(&pTextElement);
    assert(pTextElement);
	pTextElement->SetColor(0xffffff00);
	//pTextElement->SetFontBold(true);
	//pTextElement->SetFontItalic(true);
	pTextElement->SetFontSize(29);
	pTextElement->SetText("Hello Text go go !\rHi �й���\r1234");
    if(pFontEngine->GetFontCount() > 0)
    {
    	pFontEngine->GetFontName(1, szFamilyName);
    	pTextElement->SetFontFamily(szFamilyName);
		TextFont sTextFont = { 0 };
		sTextFont.iFontIndex = 10;
		sTextFont.iFontSize  = 180;
		sTextFont.iColor     = 0xff0000ff;
		pTextElement->SetTextFont(2, sTextFont);
		for (int i = 6; i < 10; i++)
		{
			sTextFont.iFontIndex = 20;
			sTextFont.iFontSize  = 100;
			sTextFont.iColor     = 0xffff5cfe;
			sTextFont.bBold      = true;
			sTextFont.bItalic    = true;
			pTextElement->SetTextFont(i, sTextFont);
			TextBorder sTextBorder = { 0 };
			sTextBorder.bEnable = true;
			sTextBorder.iSize = 10;
			sTextBorder.iColor1 = 0xffff0000;
			sTextBorder.iAlpha = 255;
			sTextBorder.iBlurRadius = 0;
			pTextElement->SetTextBorder(sTextBorder, i);
		}
		sTextFont.iFontIndex = pFontEngine->GetFontIndex(szFamilyName);
		sTextFont.iFontSize  = 80;
		sTextFont.iColor     = 0xffff0000;
		pTextElement->SetTextFont(27, sTextFont);
		sTextFont.iFontIndex = pFontEngine->GetFontIndex(szFamilyName);
		sTextFont.iFontSize  = 100;
		sTextFont.iColor     = 0xffff5c00;
		pTextElement->SetTextFont(24, sTextFont);
    }
	TextBorder sTextBorder  = { 0 };
	sTextBorder.bEnable     = true;
	sTextBorder.iSize       = 6;
	sTextBorder.iColor1     = 0xffffa0a0;
	sTextBorder.iAlpha      = 255;
	sTextBorder.iBlurRadius = 0;
	//pTextElement->SetTextBorder(sTextBorder);
	TextShadow sTextShadow  = { 0 };
	sTextShadow.bEnable     = true;
	sTextShadow.iColor      = 0xffff00ff;
	sTextShadow.iAlpha      = 100;
	sTextShadow.iBlurRadius = 3;
	sTextShadow.iDistance   = 5;
	sTextShadow.iDirection  = 3;
	pTextElement->SetTextShadow(sTextShadow);
	ITextLayout* pTextLayout = pTextElement->TextLayout();
	pTextLayout->SetHCharSpace(20);
	pTextLayout->SetVCharSpace(50);
	pTextElement->SetAdaptiveSize(1280, 720);
	ITextImage* pTextImage1 = pTextElement->TextImage()->Clone();
	cout << pTextImage1->GetWidth() << "x" << pTextImage1->GetHeight() << " - "
		<< pTextImage1->GetPitch() << endl;
	pTextImage1->SaveFile(strOutputPng);

	if (pTextImage1->GetWidth() && pTextImage1->GetHeight())
	{
		SDLWindow SDLWin;
		SDLWin.Init(pTextImage1->GetWidth(), pTextImage1->GetHeight());
		SDLWin.Update(static_cast<const char*>(pTextImage1->GetBits()));
		SDLWin.EventLoop();
	}

    pTextImage->Release();
	pTextElement->Release();

	return 0;
}