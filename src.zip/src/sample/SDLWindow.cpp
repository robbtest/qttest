#include "SDL.h"
#include "SDLWindow.h"
#include "MacroDefine.h"

#include <iostream>
using namespace std;

SDLWindow::SDLWindow()
{

}


SDLWindow::~SDLWindow()
{
	UnInit();
}

int SDLWindow::Init(int iWidth, int iHeight)
{
	int iRet = 0;

	do 
	{
		//
		CHECK_BREAK(iWidth  == 0 && (iRet = 1) != 0);
		CHECK_BREAK(iHeight == 0 && (iRet = 1) != 0);
		// 
		int iInitRet = SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
		if (iInitRet != 0)
		{
			cout << "Could not initialize SDL - :" << SDL_GetError() << endl;
		}
		CHECK_BREAK(iInitRet != 0 && (iRet = 1) != 0);
		// 
		m_pWin = SDL_CreateWindow("Text Test", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
			iWidth, iHeight, SDL_WINDOW_OPENGL);
		if (m_pWin == nullptr)
		{
			cout << "SDL: could not create window - :" << SDL_GetError() << endl;
		}
		CHECK_BREAK(m_pWin == nullptr && (iRet = 1) != 0);
		// 
		m_pRenderer = SDL_CreateRenderer(m_pWin, -1, 0);
		if (m_pRenderer == nullptr)
		{
			cout << "SDL: could not create render - :" << SDL_GetError() << endl;
		}
		CHECK_BREAK(m_pRenderer == nullptr && (iRet = 2) != 0);
		// 
		Uint32 pixformat = SDL_PIXELFORMAT_ARGB8888;
		m_pTexture = SDL_CreateTexture(m_pRenderer, pixformat, SDL_TEXTUREACCESS_STREAMING, iWidth, iHeight);
		if (m_pTexture == nullptr)
		{
			cout << "SDL: could not create texture - :" << SDL_GetError() << endl;
		}
		CHECK_BREAK(m_pTexture == nullptr && (iRet = 3) != 0);
		m_uWidth  = iWidth;
		m_uHeight = iHeight;
	} while (false);

	return iRet;
}

void SDLWindow::Update(const char* pSkBitmap)
{
	CHECK_RETURN(pSkBitmap == nullptr);

	SDL_Rect rect = { 0, 0, (int)m_uWidth, (int)m_uHeight };
	SDL_UpdateTexture(m_pTexture, NULL, pSkBitmap, m_uWidth * 4);

	SDL_RenderClear(m_pRenderer);
	SDL_RenderCopy(m_pRenderer, m_pTexture, NULL, &rect);
	SDL_RenderPresent(m_pRenderer);
}

int SDLWindow::EventLoop()
{
	SDL_Event event;

	while (1)
	{
		SDL_WaitEvent(&event);
		//SDL_PollEvent(&event);

		CHECK_BREAK(event.type == SDL_QUIT);

		switch (event.type)
		{
		case SDL_KEYUP:
			OnEvent_Keyup(&event);
			break;
		default:
			break;
		}
	}

	return 0;
}

void SDLWindow::UnInit()
{
	SDL_Delay(10);

	if (m_pTexture)
	{
		SDL_DestroyTexture(m_pTexture);
	}
	if (m_pRenderer)
	{
		SDL_DestroyRenderer(m_pRenderer);
	}
	if (m_pWin)
	{
		SDL_DestroyWindow(m_pWin);
	}
	SDL_Quit();
}

void SDLWindow::OnEvent_Keyup(SDL_Event* pEvent)
{
	SDL_KeyboardEvent* pKeyupEvent = &(pEvent->key);
	if (pKeyupEvent->keysym.scancode == SDL_SCANCODE_Q)
	{
		OnEvent_KeyupQ(pKeyupEvent);
	}
	else if (pKeyupEvent->keysym.scancode == SDL_SCANCODE_R)
	{
		OnEvent_KeyupR(pKeyupEvent);
	}
	else if (pKeyupEvent->keysym.scancode == SDL_SCANCODE_UP)
	{
		OnEvent_KeyupUp(pKeyupEvent);
	}
}

void SDLWindow::OnEvent_KeyupQ(SDL_KeyboardEvent* pEvent)
{
	const SDL_MessageBoxButtonData buttons[] = {
	//	{ /* .flags, .buttonid, .text */        0, 0, "no" },
		{ SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 1, "yes" },
		{ SDL_MESSAGEBOX_BUTTON_ESCAPEKEY_DEFAULT, 2, "cancel" },
	};
	const SDL_MessageBoxColorScheme colorScheme = {
		{ /* .colors (.r, .g, .b) */
			/* [SDL_MESSAGEBOX_COLOR_BACKGROUND] */
			{ 255,   0,   0 },
			/* [SDL_MESSAGEBOX_COLOR_TEXT] */
			{   0, 255,   0 },
			/* [SDL_MESSAGEBOX_COLOR_BUTTON_BORDER] */
			{ 255, 255,   0 },
			/* [SDL_MESSAGEBOX_COLOR_BUTTON_BACKGROUND] */
			{   0,   0, 255 },
			/* [SDL_MESSAGEBOX_COLOR_BUTTON_SELECTED] */
			{ 255,   0, 255 }
		}
	};

	const SDL_MessageBoxData messageboxdata = {
		SDL_MESSAGEBOX_INFORMATION,		/* .flags */
		NULL,							/* .window */
		"tip",			                /* .title */
		"Are you sure to exit ?",	    /* .message */
		SDL_arraysize(buttons),			/* .numbuttons */
		buttons,						/* .buttons */
		&colorScheme					/* .colorScheme */
	};
	int buttonid;
	if (SDL_ShowMessageBox(&messageboxdata, &buttonid) < 0) 
	{
		SDL_Log("error displaying message box");
	}

	if (buttonid == 1)
	{
		SDL_Event event = { SDL_QUIT };
		SDL_PushEvent(&event);
	}

}

void SDLWindow::OnEvent_KeyupR(SDL_KeyboardEvent* pEvent)
{

}

void SDLWindow::OnEvent_KeyupUp(SDL_KeyboardEvent* pEvent)
{

}