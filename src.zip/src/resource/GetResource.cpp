#include "GetResource.h"
#include <stdlib.h>
#include <string.h>

extern const unsigned char* get_file_dtype_inf_();
extern const unsigned char* get_file_arialuni_ttf_0();
extern const unsigned char* get_file_arialuni_ttf_1();
extern const unsigned char* get_file_arialuni_ttf_2();
extern const unsigned char* get_file_arialuni_ttf_3();

extern const unsigned int   get_file_dtype_inf_size_();
extern const unsigned int   get_file_arialuni_ttf_0_size();
extern const unsigned int   get_file_arialuni_ttf_1_size();
extern const unsigned int   get_file_arialuni_ttf_2_size();
extern const unsigned int   get_file_arialuni_ttf_3_size();

unsigned char* g_file_arialuni_ttf_ptr  = nullptr;
unsigned int   g_file_arialuni_ttf_size = 0;

const unsigned char* get_file_dtype_inf()     
{
	return get_file_dtype_inf_();
}
const unsigned int get_file_dtype_inf_size()
{
	return get_file_dtype_inf_size_();
}

const unsigned char* get_file_arialuni_ttf()
{
	if (g_file_arialuni_ttf_ptr == nullptr)
	{
		const unsigned int iSize = get_file_arialuni_ttf_size();
		g_file_arialuni_ttf_ptr = (unsigned char*)malloc(iSize);
		unsigned char* file_arialuni_ttf_ptr = g_file_arialuni_ttf_ptr;
		memcpy(file_arialuni_ttf_ptr, get_file_arialuni_ttf_0(), get_file_arialuni_ttf_0_size());
		file_arialuni_ttf_ptr += get_file_arialuni_ttf_0_size();
		memcpy(file_arialuni_ttf_ptr, get_file_arialuni_ttf_1(), get_file_arialuni_ttf_1_size());
		file_arialuni_ttf_ptr += get_file_arialuni_ttf_1_size();
		memcpy(file_arialuni_ttf_ptr, get_file_arialuni_ttf_2(), get_file_arialuni_ttf_2_size());
		file_arialuni_ttf_ptr += get_file_arialuni_ttf_2_size();
		memcpy(file_arialuni_ttf_ptr, get_file_arialuni_ttf_3(), get_file_arialuni_ttf_3_size());
	}
	return g_file_arialuni_ttf_ptr;
}

const unsigned int get_file_arialuni_ttf_size()
{
	if (g_file_arialuni_ttf_size == 0)
	{
		g_file_arialuni_ttf_size += get_file_arialuni_ttf_0_size();
		g_file_arialuni_ttf_size += get_file_arialuni_ttf_1_size();
		g_file_arialuni_ttf_size += get_file_arialuni_ttf_2_size();
		g_file_arialuni_ttf_size += get_file_arialuni_ttf_3_size();
	}
	return g_file_arialuni_ttf_size;
}

const unsigned char* get_file_arialuni_ttf_free()
{
	if (g_file_arialuni_ttf_ptr != nullptr)
	{
		free(g_file_arialuni_ttf_ptr);
		g_file_arialuni_ttf_ptr = nullptr;
	}
	return g_file_arialuni_ttf_ptr;
}

//const unsigned char* get_test_file()
//{
//	return file_arialuni_ttf_0;
//}
//
//const unsigned int   get_test_file_size()
//{
//	return sizeof(file_arialuni_ttf_0);
//}