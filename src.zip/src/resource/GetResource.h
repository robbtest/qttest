#pragma once

#ifndef _GET_RESOURCE_H_
#define _GET_RESOURCE_H_

#if defined(RES_EXPORTS)
#if defined(_MSC_VER)
#define RES_API __declspec(dllexport)
#else
#define RES_API __attribute__((visibility("default"))) 
#endif
#else
#if defined(_MSC_VER)
#define RES_API __declspec(dllimport)
#else
#define RES_API 
#endif
#endif

RES_API const unsigned char* get_file_dtype_inf();
RES_API const unsigned int   get_file_dtype_inf_size();
RES_API const unsigned char* get_file_arialuni_ttf();
RES_API const unsigned int   get_file_arialuni_ttf_size();
RES_API const unsigned char* get_file_arialuni_ttf_free();

#endif // _GET_RESOURCE_H_