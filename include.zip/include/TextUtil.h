#pragma once

#ifndef _TEXT_UTIL_H_
#define _TEXT_UTIL_H_

#if defined(TEXT_EXPORTS)
#if defined(_MSC_VER)
#define TEXT_API __declspec(dllexport)
#else
#define TEXT_API __attribute__((visibility("default"))) 
#endif
#else
#if defined(_MSC_VER)
#define TEXT_API __declspec(dllimport)
#else
#define TEXT_API 
#endif
#endif


#include "IFontEngine.h"
#include "ITextImage.h"
#include "ITextElement.h"

namespace TextEngine
{

// Text interface tool class
class TEXT_API TextUtil
{
public:
	static IFontEngine* GetFontEngine();
	static int          CreateTextImage(ITextImage** ppTextImage);
	static int          CreateTextElement(ITextElement** ppTextElement);
};

}
#endif // _TEXT_UTIL_H_