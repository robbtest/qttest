#pragma once

#ifndef _ITEXT_ELEMENT_H_
#define _ITEXT_ELEMENT_H_

#include "TextDataDefine.h"
#include "PlatformDefine.h"

namespace TextEngine
{

class ITextImage;
class ITextLayout;

// 
class ITextElement
{
public:
	// Set and Get Paramter
	virtual void                __stdcall Release()                  = 0;
	virtual void                __stdcall SetAdaptiveSize(int , int) = 0;
	virtual void                __stdcall SetText(const char*)       = 0;
	virtual const char*         __stdcall GetText()                  = 0;
	virtual void                __stdcall SetFontSize(int)           = 0;
	virtual void                __stdcall SetColor(unsigned long)    = 0;
	virtual void                __stdcall SetFontFamily(const char*) = 0;
	virtual void                __stdcall SetFontBold(bool )         = 0;
	virtual void                __stdcall SetFontItalic(bool )       = 0;
	virtual void                __stdcall SetTextFont(int , const TextFont& ) = 0;
	virtual TextFont            __stdcall GetTextFont(int )          = 0;
	virtual void                __stdcall SetTextBorder(const TextBorder& , int  = -1) = 0;
	virtual TextBorder          __stdcall GetTextBorder(int )        = 0;
	virtual void                __stdcall SetTextShadow(const TextShadow& , int  = -1) = 0;
	virtual TextShadow         __stdcall GetTextShadow(int )        = 0;
	// Output
	virtual ITextImage*         __stdcall TextImage()                = 0;
	virtual ITextLayout*        __stdcall TextLayout()               = 0;
};

}
#endif // _ITEXT_ELEMENT_H_
