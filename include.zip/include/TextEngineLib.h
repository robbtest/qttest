#pragma once

#ifndef _TEXT_ENGINE_LIB_H_
#define _TEXT_ENGINE_LIB_H_

#ifdef __linux__
	#ifndef LINUX
	#define LINUX
	#endif // LINUX
#endif // __linux__

//
#include "TextUtil.h"

//
#include "IFontEngine.h"
#include "ITextImage.h"
#include "ITextElement.h"
#include "ITextLayout.h"

//
#include "TextDataDefine.h"

#endif // _TEXT_ENGINE_LIB_H_