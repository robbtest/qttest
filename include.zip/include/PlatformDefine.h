#pragma once

#ifndef _PLATFORM_DEFINE_H_
#define _PLATFORM_DEFINE_H_


#if !defined(WIN32) && !defined(WIN64)
#ifndef __stdcall
#define __stdcall __attribute__((stdcall)) 
#endif
#endif

#endif // _PLATFORM_DEFINE_H_