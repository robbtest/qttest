#pragma once

#ifndef _IFONT_ENGINE_H_
#define _IFONT_ENGINE_H_

#include "PlatformDefine.h"


namespace TextEngine
{ 

// Font interface
class IFontEngine
{
public:
	virtual int 	    __stdcall Init()                                   = 0;
	virtual int         __stdcall LoadFonts(const char* szFontFold)        = 0;
	virtual int         __stdcall GetFontCount()                           = 0;
	virtual int         __stdcall GetFontName(int nIndex, char* pFontName) = 0;
	virtual int         __stdcall GetFontIndex(const char* pFontName)      = 0;
};

}
#endif // _IFONT_ENGINE_H_