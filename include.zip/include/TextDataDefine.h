#pragma once

#include <vector>

namespace TextEngine
{

struct TTextFont
{
	bool            bNotNull;       // Not null
	unsigned int    iFontIndex;		// Font index
	int			    iFontSize;		// Font size
	int			    iColor;		    // Text color
	bool            bBold;          // bold
	bool            bItalic;        // italic
	int			    iBgColor;	    // Text Backgrounp color
};
using TextFont = struct TTextFont;

struct TTextBorder
{
	bool            bNotNull;       // Not null
	bool			bEnable;		// 1-Enable, 0-Disable
	int			    iSize;			// 0-10
	int			    iColor1;		// Start Color
	int			    iAlpha;			// 0-255
	int			    iBlurRadius;	// 0-10
};
using TextBorder = struct TTextBorder;

struct TTextShadow
{
	bool            bNotNull;       // Not null
	int				bEnable;		// 1-Enable, 0-Disable
	int			    iColor;			// Shadow color
	int			    iAlpha;			// 0-255
	int			    iBlurRadius;	// 0-10
	int			    iDistance;		// 0-100
	int			    iDirection;		// 0-7
};
using TextShadow = struct TTextShadow;

struct TTextInfo
{
	TextFont        sTextFont;
	TextBorder      sTextBorder;
	TextShadow      sTextShadow;
};
using TextInfo    = struct TTextInfo;
using TextInfoVec = std::vector<TextInfo>;

}