#pragma once

#ifndef _ITEXT_IMAGE_H_
#define _ITEXT_IMAGE_H_

#include <cstdint>
#include "PlatformDefine.h"


namespace TextEngine
{ 

//
class ITextImage
{
public:
	// 
	virtual void        __stdcall Release()     = 0;
	virtual int         __stdcall Alloc(uint32_t uWidth, uint32_t uHeight, uint32_t nBitCount) = 0;
	virtual ITextImage*	__stdcall Clone()       = 0;
	// 
	virtual int         __stdcall GetWidth()    = 0;
	virtual int         __stdcall GetHeight()   = 0;
	virtual int         __stdcall GetPitch()    = 0;
	virtual int         __stdcall GetBitCount() = 0;
	virtual const char* __stdcall GetBits()     = 0;
	// 
	virtual void        __stdcall FillColor(uint32_t uColor)      = 0;
	// 
	virtual int         __stdcall LoadFile(const char* pFileName) = 0;
	virtual int         __stdcall SaveFile(const char* pFileName) = 0;
};

}
#endif // _ITEXT_IMAGE_H_