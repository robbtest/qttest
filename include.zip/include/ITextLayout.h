#pragma once

#ifndef _ITEXT_LAYOUT_H_
#define _ITEXT_LAYOUT_H_

#include <cstdint>
#include "PlatformDefine.h"


namespace TextEngine
{ 

//
class ITextLayout
{
public:
	// 
	virtual void   __stdcall Release()          = 0;
	virtual void   __stdcall SetHCharSpace(int) = 0;
	virtual void   __stdcall SetVCharSpace(int) = 0;
};

}
#endif // _ITEXT_LAYOUT_H_